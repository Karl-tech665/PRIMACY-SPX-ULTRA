globalThis.crypto = require('node:crypto').webcrypto;

// Baileys' encryption library prints whole session objects (including private keys) to the console
// and spams stack traces when it cannot read a message from a sender it has no keys for yet.
// Drop those lines so keys never end up in Render logs and real errors stay visible.
const SENSITIVE_LOG = /^(Closing session|Closing open session|Closing stale open session|Removing old closed session|Opening session|Migrating session|Session already|Decrypted message with closed session|Session error:.*Bad MAC|Failed to decrypt message with any known session)/;
for (const level of ['log', 'info', 'warn', 'debug', 'error']) {
    const original = console[level].bind(console);
    console[level] = (...args) => {
        if (typeof args[0] === 'string' && SENSITIVE_LOG.test(args[0])) return;
        original(...args);
    };
}

require('dotenv').config();
const path = require('path');
const fs = require('fs');
const express = require('express');
const figlet = require('figlet');
const chalk = require('chalk');
const pino = require('pino');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, proto } = require('@whiskeysockets/baileys');

const config = require('./config/config');
const { loadCommands } = require('./utils/commandLoader');
const { enforceProtection } = require('./utils/protection');
const { autoJoinGroups, autoFollowChannels } = require('./utils/autoFeatures');
const { sendWelcome, sendSessionId } = require('./utils/welcome');
const { unwrap } = require('./utils/media');
const settingsStore = require('./utils/settingsStore');
const groupSettings = require('./utils/groupSettingsStore');
const quotes = require('./autobioQuotes.json');

const logger = pino({ level: 'silent' });
const commands = loadCommands(path.join(__dirname, 'commands')); // Map
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const sessions = new Map();         // id -> socket
const pendingPairings = new Map();  // id -> { resolve, reject, phone, timeout }
const reconnectTimers = new Map();  // id -> timeout
const welcomePending = new Set();   // ids that were just paired and still need their welcome message

// Sessions are stored as files, exactly like the minimal script that paired fine.
// On Render's free plan this folder is wiped on every deploy/restart, so numbers must be paired again.
const SESSION_ROOT = process.env.SESSION_DIR || path.join(__dirname, 'session');

function deleteSessionFiles(id) {
    try { fs.rmSync(path.join(SESSION_ROOT, id), { recursive: true, force: true }); } catch (e) {}
}

function stopTimers(sock) {
    for (const t of sock?.__timers || []) clearInterval(t);
    if (sock) sock.__timers = [];
}

function destroySocket(id) {
    if (reconnectTimers.has(id)) { clearTimeout(reconnectTimers.get(id)); reconnectTimers.delete(id); }
    const old = sessions.get(id);
    if (old) {
        stopTimers(old);
        try { old.ev.removeAllListeners(); old.end(undefined); } catch (e) {}
        sessions.delete(id);
    }
}

// Only if you set WA_VERSION on Render (e.g. 2.3000.1055177075) do we override Baileys' own default version
function getWaVersion() {
    if (!process.env.WA_VERSION) return undefined;
    const v = process.env.WA_VERSION.split(/[.,]/).map(n => parseInt(n, 10)).filter(n => !isNaN(n));
    if (v.length === 3) { console.log(`🌐 Using WA_VERSION override ${v.join('.')}`); return v; }
    console.log('⚠️ WA_VERSION is not in the form 2.3000.1055177075, ignoring it.');
    return undefined;
}

async function createSession(id, phone) {
    const { state, saveCreds } = await useMultiFileAuthState(path.join(SESSION_ROOT, id));
    const version = getWaVersion();

    // Remember recent messages so WhatsApp can re-request them. Without this, a message the
    // phone could not decrypt shows "Waiting for this message" forever.
    const msgStore = new Map();
    const rememberMsg = (m) => {
        if (m?.key?.id && m.message) {
            msgStore.set(m.key.id, m.message);
            if (msgStore.size > 500) msgStore.delete(msgStore.keys().next().value);
        }
    };

    const sock = makeWASocket({
        ...(version ? { version } : {}),
        auth: state, logger,
        browser: ['Ubuntu', 'Chrome', '20.0.04'],
        connectTimeoutMs: 60000,
        printQRInTerminal: false,
        getMessage: async (key) => msgStore.get(key.id)
    });
    sock.__timers = [];
    sessions.set(id, sock);
    sock.ev.on('creds.update', saveCreds);

    let codeRequested = false;
    const requestCode = async () => {
        if (codeRequested || state.creds.registered || !pendingPairings.has(id)) return;
        codeRequested = true;
        const pending = pendingPairings.get(id);
        try {
            const code = await sock.requestPairingCode(pending.phone);
            console.log(`🔑 Pairing code generated for ${pending.phone}`);
            welcomePending.add(id);
            clearTimeout(pending.timeout);
            pendingPairings.delete(id);
            pending.resolve(code);
        } catch (e) {
            console.error('❌ Failed to generate code:', e.message);
            clearTimeout(pending.timeout);
            pendingPairings.delete(id);
            pending.reject(e);
        }
    };

    sock.ev.on('connection.update', async (update) => {
        const { connection, qr, lastDisconnect } = update;
        if (connection) console.log(`🔄 [${id}] ${connection}`);

        // Ask for the code 3s after 'connecting' (the QR event is a fallback)
        if (connection === 'connecting') setTimeout(requestCode, 3000);
        if (qr) setTimeout(requestCode, 1500);

        if (connection === 'open') {
            console.log(`✅ ${id} connected as ${sock.user.id}`);

            // Optional per-number features, switched on with .alwaysonline / .autobio / .autoread
            stopTimers(sock);
            sock.__timers.push(setInterval(() => {
                if (settingsStore.get(`${phone}_alwaysonline`, false)) sock.sendPresenceUpdate('available').catch(() => {});
            }, 30000));
            sock.__timers.push(setInterval(async () => {
                if (settingsStore.get(`${phone}_autobio`, false)) {
                    try { await sock.updateProfileStatus(quotes[Math.floor(Math.random() * quotes.length)]); } catch (e) {}
                }
            }, 3600000));

            // Only right after a fresh pairing, and only after a pause so the new device's
            // encryption keys are ready (sending instantly causes "Waiting for this message").
            if (welcomePending.has(id)) {
                welcomePending.delete(id);
                setTimeout(async () => {
                    try { await sendWelcome(sock, phone, commands); } catch (e) { console.error('Welcome message failed:', e.message); }
                    // The session ID goes out as separate messages, a few seconds after the welcome card
                    try { await new Promise(r => setTimeout(r, 3000)); await sendSessionId(sock, phone, state.creds); } catch (e) { console.error('Session ID message failed:', e.message); }
                    autoJoinGroups(sock, phone).catch(() => {});
                    autoFollowChannels(sock, phone).catch(() => {});
                }, 8000);
            }
        }

        if (connection === 'close') {
            if (sessions.get(id) !== sock) return; // replaced/destroyed on purpose
            stopTimers(sock);
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            console.log(`⚠️ [${id}] closed (code ${statusCode}) ${lastDisconnect?.error?.message || ''}`);
            sessions.delete(id);
            if (statusCode === DisconnectReason.loggedOut) {
                deleteSessionFiles(id);
                console.log(`🚪 ${id} logged out — cleared, ready to re-pair.`);
            } else {
                // Includes restartRequired (515) which WhatsApp sends right after a successful link
                const t = setTimeout(() => {
                    reconnectTimers.delete(id);
                    createSession(id, phone).catch(e => console.error(`Reconnect failed for ${id}:`, e.message));
                }, 3000);
                reconnectTimers.set(id, t);
            }
        }
    });

    // Welcome / goodbye messages (switched on per group with .welcome on / .goodbye on)
    sock.ev.on('group-participants.update', async (ev) => {
        try {
            const wantWelcome = ev.action === 'add' && groupSettings.get(ev.id, 'welcome', false);
            const wantBye = ev.action === 'remove' && groupSettings.get(ev.id, 'goodbye', false);
            if (!wantWelcome && !wantBye) return;
            const meta = await sock.groupMetadata(ev.id);
            for (const p of ev.participants) {
                const jid = typeof p === 'string' ? p : (p.id || p.jid);
                if (!jid) continue;
                const tag = '@' + jid.split('@')[0].split(':')[0];
                const text = wantWelcome
                    ? `👋 Welcome ${tag} to *${meta.subject}*!\nPlease read the group rules and enjoy your stay. 🎉`
                    : `👋 Goodbye ${tag}. We'll miss you!`;
                await sock.sendMessage(ev.id, { text, mentions: [jid] });
            }
        } catch (e) { console.log('Group update failed:', e.message); }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        for (const m of messages) rememberMsg(m);
        if (type !== 'notify') return;
        for (const msg of messages) {
            try {
                if (!msg.message) continue;
                const from = msg.key.remoteJid;
                if (!from || from === 'status@broadcast' || from.endsWith('@newsletter')) continue;

                // Auto-read (switched on with .autoread)
                if (settingsStore.get(`${phone}_autoread`, false) && !msg.key.fromMe) {
                    try { await sock.readMessages([msg.key]); } catch (e) {}
                }

                const fromMe = !!msg.key.fromMe;
                const isGroup = from.endsWith('@g.us');
                const myJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
                const sender = fromMe ? myJid : (isGroup ? (msg.key.participant || from) : from);
                const m = unwrap(msg.message) || msg.message;
                const text = m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || '';

                if (isGroup && !fromMe) {
                    const actioned = await enforceProtection(sock, from, sender, msg, text);
                    if (actioned) continue;
                }

                const prefix = config.PREFIX;
                if (!text.startsWith(prefix)) continue;
                const args = text.slice(prefix.length).trim().split(/\s+/);
                const cmdName = (args.shift() || '').toLowerCase();
                if (!cmdName) continue;
                console.log(`📩 [${id}] ${prefix}${cmdName} from ${sender.split('@')[0]}${isGroup ? ' (group)' : ''}`);

                const command = commands.get(cmdName);
                if (!command) { console.log(`❔ Unknown command: ${cmdName}`); continue; }

                await command.execute(sock, from, args, msg, {
                    commands, sender, isGroup, fromMe, sessionOwner: phone, pushName: msg.pushName || '', id
                });
                console.log(`✅ [${id}] ${cmdName} done`);
            } catch (e) { console.error(`[${id}] Message error:`, e.message); }
        }
    });

    return sock;
}

// ─── PAIRING API ───
app.post('/pair', async (req, res) => {
    const phone = String(req.body.phone || '').replace(/\D/g, '');
    if (phone.length < 10) return res.status(400).json({ error: 'Invalid phone number' });

    const id = `user_${phone}`;
    try {
        // Cancel anything left over from a previous attempt, then start clean
        if (pendingPairings.has(id)) {
            const p = pendingPairings.get(id); clearTimeout(p.timeout); pendingPairings.delete(id);
            p.reject(new Error('Superseded by a new pairing request'));
        }
        destroySocket(id);
        // Give the old socket a moment to finish writing its files, otherwise stale key files
        // can reappear after we wipe the folder and corrupt the new session (causes "Bad MAC").
        await new Promise(r => setTimeout(r, 1500));
        deleteSessionFiles(id);

        console.log(`⏳ Creating session for ${phone}...`);
        const codePromise = new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                pendingPairings.delete(id);
                reject(new Error('Timed out waiting for WhatsApp. Try again.'));
            }, 45000);
            pendingPairings.set(id, { resolve, reject, phone, timeout });
        });
        codePromise.catch(() => {}); // avoid unhandled rejection if superseded

        await createSession(id, phone);
        const code = await codePromise;
        res.json({ success: true, code });
    } catch (e) {
        console.error('❌ Error in /pair:', e.message);
        pendingPairings.delete(id);
        destroySocket(id);
        if (!res.headersSent) res.status(500).json({ error: e.message });
    }
});

// Handy for uptime monitors (they stop Render's free plan from falling asleep)
app.get('/health', (req, res) => res.send('OK'));

// SESSION_ID (the "session ID" message sent after pairing) lets a number come back online after a
// redeploy without pairing again. Several IDs can be separated by commas or spaces.
function importSessionIds() {
    const raw = process.env.SESSION_ID;
    if (!raw) return;
    for (const piece of raw.split(/[\s,]+/).filter(Boolean)) {
        try {
            const json = Buffer.from(piece.replace(/^PRIMACY-SPX:~/, ''), 'base64').toString('utf8');
            const creds = JSON.parse(json);
            const num = String(creds?.me?.id || '').split('@')[0].split(':')[0];
            if (!/^\d{8,}$/.test(num)) throw new Error('no phone number inside it');
            const dir = path.join(SESSION_ROOT, `user_${num}`);
            if (!fs.existsSync(path.join(dir, 'creds.json'))) {
                fs.mkdirSync(dir, { recursive: true });
                fs.writeFileSync(path.join(dir, 'creds.json'), json);
                console.log(`🔑 Imported SESSION_ID for ${num}`);
            }
        } catch (e) { console.log('⚠️ Could not read SESSION_ID:', e.message); }
    }
}

// Reconnects numbers whose session folders survived a restart (for example when SESSION_DIR points at a
// persistent disk), after importing any SESSION_ID values above.
async function restoreSessions() {
    try {
        importSessionIds();
        if (!fs.existsSync(SESSION_ROOT)) return;
        for (const dir of fs.readdirSync(SESSION_ROOT)) {
            const m = dir.match(/^user_(\d{8,})$/);
            if (!m || sessions.has(dir)) continue;
            console.log(`♻️ Restoring session ${dir}`);
            await createSession(dir, m[1]).catch(e => console.error(`Restore failed for ${dir}:`, e.message));
        }
    } catch (e) { console.error('Restore error:', e.message); }
}

app.listen(PORT, () => {
    console.log(chalk.green(figlet.textSync('PRIMACY SPX', { font: 'Standard' })));
    console.log(chalk.cyan(`🚀 Multi-Session Pairing Site running at port ${PORT}`));
    console.log('📦 Loaded ' + new Set(commands.values()).size + ' commands');
    restoreSessions();
});
process.on('uncaughtException', (e) => console.error('Uncaught:', e));
process.on('unhandledRejection', (e) => console.error('Rejection:', e));
