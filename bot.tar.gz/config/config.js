const path = require("path");

module.exports = {
    BOT_NAME: "𝐏𝐑𝐈𝐌𝐀𝐂𝐘_𝐒𝐏𝐗_𝐔𝐋𝐓𝐑𝐀",
    VERSION: "2.1.0",
    MODE: process.env.BOT_MODE || "PUBLIC",
    OWNER_NAME: process.env.OWNER_NAME || "༒♔𝕻𝖗𝖎𝖒𝖊♔༒",
    OWNER_NUMBER: process.env.OWNER_NUMBER || "254718711525",
    FOOTER_BRAND: "PRIME",
    PREFIX: process.env.PREFIX || ".",

    // Images are stored inside the repo (assets/ folder), so they never depend on imgur or any
    // other website. Replace assets/menu.jpg and assets/repo.jpg with your own pictures any time.
    MENU_IMAGE: path.join(__dirname, "..", "assets", "menu.jpg"),
    REPO_IMAGE: path.join(__dirname, "..", "assets", "repo.jpg"),

    GITHUB_USER: "Karl-tech665",
    GITHUB_REPO: "PRIMACY-SPX-ULTRA",

    PROXY: {
        LINK: "https://wa.me/proxy?host=de.greenapi.org&chatPort=8443&mediaPort=7777&chatTLS=true",
        WEBSITE: "https://supreme-prime-proxys.vercel.app"
    },
    AUTO_JOIN_GROUPS: ["L4j0bHtzkUuAYvyD9pD3QL", "GOM37kv0jVuIvkKveOv2JD"],
    AUTO_FOLLOW_CHANNELS: ["0029Vb8sraAH5JM5WTpz0X0z", "0029Vb84TR9IXnltkyhYEC3R"]
};
