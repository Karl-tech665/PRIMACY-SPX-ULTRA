const config = require("../config/config");
const groupSettings = require("../utils/groupSettingsStore");
const { isOwner, isAdmin, isBotAdmin } = require("../utils/auth");
const { box, jidNum } = require("../utils/helpers");

const say = (sock, from, msg, text, extra = {}) => sock.sendMessage(from, { text, ...extra }, { quoted: msg });

function targetOf(args, msg) {
    const ctx = msg.message?.extendedTextMessage?.contextInfo;
    const d = args[0]?.replace(/\D/g, "");
    return ctx?.mentionedJid?.[0] || ctx?.participant || (d && d.length >= 8 ? d + "@s.whatsapp.net" : null);
}

// Runs a group action after checking: group chat, sender is admin/owner, (optionally) the bot is admin
async function guarded(sock, from, msg, extra, fn, { needBotAdmin = true } = {}) {
    if (!from.endsWith("@g.us")) return say(sock, from, msg, "❌ This command only works in groups.");
    const sender = extra.sender || msg.key.participant || from;
    if (!isOwner(sender, extra) && !(await isAdmin(sock, from, sender))) return say(sock, from, msg, "❌ Only group admins can use this.");
    if (needBotAdmin && !(await isBotAdmin(sock, from))) return say(sock, from, msg, "❌ Make me a group admin first, then try again.");
    try { await fn(); } catch (e) { console.log("group command failed:", e.message); await say(sock, from, msg, "❌ WhatsApp refused that action. Make sure I am an admin and try again."); }
}

module.exports = [
    {
        name: "tagall", aliases: ["everyone"],
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => {
                const meta = await sock.groupMetadata(from);
                const mentions = meta.participants.map(p => p.id);
                const body = meta.participants.map(p => `┃ @${jidNum(p.id)}`).join("\n");
                await sock.sendMessage(from, { text: `📢 *${args.join(" ") || "Attention everyone!"}*\n\n╭━━〔 MEMBERS (${mentions.length}) 〕━━╮\n${body}\n╰━━━━━━━━━━━━━━━━━╯`, mentions }, { quoted: msg });
            }, { needBotAdmin: false });
        }
    },
    {
        name: "hidetag", aliases: ["notify"],
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => {
                const meta = await sock.groupMetadata(from);
                await sock.sendMessage(from, { text: args.join(" ") || "📣", mentions: meta.participants.map(p => p.id) });
            }, { needBotAdmin: false });
        }
    },
    {
        name: "groupinfo", aliases: ["ginfo"],
        async execute(sock, from, args, msg) {
            if (!from.endsWith("@g.us")) return say(sock, from, msg, "❌ This command only works in groups.");
            const m = await sock.groupMetadata(from);
            const admins = m.participants.filter(p => p.admin).length;
            await say(sock, from, msg, box("GROUP INFO", [
                `📛 *Name:* ${m.subject}`, `👥 *Members:* ${m.participants.length}`, `👑 *Admins:* ${admins}`,
                `📅 *Created:* ${new Date((m.creation || 0) * 1000).toLocaleDateString("en-GB")}`, `📝 *About:* ${(m.desc || "None").slice(0, 200)}`
            ]));
        }
    },
    {
        name: "admins", aliases: ["listadmins"],
        async execute(sock, from, args, msg) {
            if (!from.endsWith("@g.us")) return say(sock, from, msg, "❌ This command only works in groups.");
            const m = await sock.groupMetadata(from);
            const list = m.participants.filter(p => p.admin).map(p => p.id);
            await say(sock, from, msg, `👑 *Group admins (${list.length})*\n\n` + list.map(a => `• @${jidNum(a)}`).join("\n"), { mentions: list });
        }
    },
    {
        name: "link", aliases: ["invite", "grouplink"],
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => {
                const code = await sock.groupInviteCode(from);
                await say(sock, from, msg, `🔗 *Group link*\nhttps://chat.whatsapp.com/${code}`);
            });
        }
    },
    {
        name: "revoke", aliases: ["resetlink"],
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => {
                const code = await sock.groupRevokeInvite(from);
                await say(sock, from, msg, `✅ Old link cancelled.\n🔗 New link: https://chat.whatsapp.com/${code}`);
            });
        }
    },
    {
        name: "setname",
        async execute(sock, from, args, msg, extra = {}) {
            if (!args.length) return say(sock, from, msg, `❌ ${config.PREFIX}setname <new group name>`);
            await guarded(sock, from, msg, extra, async () => { await sock.groupUpdateSubject(from, args.join(" ")); await say(sock, from, msg, "✅ Group name updated."); });
        }
    },
    {
        name: "setdesc",
        async execute(sock, from, args, msg, extra = {}) {
            if (!args.length) return say(sock, from, msg, `❌ ${config.PREFIX}setdesc <new description>`);
            await guarded(sock, from, msg, extra, async () => { await sock.groupUpdateDescription(from, args.join(" ")); await say(sock, from, msg, "✅ Group description updated."); });
        }
    },
    {
        name: "mute", aliases: ["close"],
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => { await sock.groupSettingUpdate(from, "announcement"); await say(sock, from, msg, "🔇 Group closed. Only admins can send messages."); });
        }
    },
    {
        name: "unmute", aliases: ["open"],
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => { await sock.groupSettingUpdate(from, "not_announcement"); await say(sock, from, msg, "🔊 Group opened. Everyone can send messages."); });
        }
    },
    {
        name: "add",
        async execute(sock, from, args, msg, extra = {}) {
            const t = targetOf(args, msg);
            if (!t) return say(sock, from, msg, `❌ ${config.PREFIX}add 2547XXXXXXXX`);
            await guarded(sock, from, msg, extra, async () => {
                const r = await sock.groupParticipantsUpdate(from, [t], "add");
                const code = r?.[0]?.status;
                await say(sock, from, msg, code === "200" || code === 200 ? `✅ Added @${jidNum(t)}` : `⚠️ Could not add @${jidNum(t)} (their privacy settings may block it). Try sending them the group link.`, { mentions: [t] });
            });
        }
    },
    {
        name: "del", aliases: ["delete"],
        async execute(sock, from, args, msg, extra = {}) {
            const ctx = msg.message?.extendedTextMessage?.contextInfo;
            if (!ctx?.stanzaId) return say(sock, from, msg, `❌ Reply to the message you want deleted with ${config.PREFIX}del`);
            await guarded(sock, from, msg, extra, async () => {
                await sock.sendMessage(from, { delete: { remoteJid: from, fromMe: false, id: ctx.stanzaId, participant: ctx.participant } });
            });
        }
    },
    {
        name: "poll",
        async execute(sock, from, args, msg) {
            const parts = args.join(" ").split("|").map(s => s.trim()).filter(Boolean);
            if (parts.length < 3) return say(sock, from, msg, `❌ ${config.PREFIX}poll Best food? | Pizza | Burger | Rice`);
            await sock.sendMessage(from, { poll: { name: parts[0], values: parts.slice(1, 13), selectableCount: 1 } });
        }
    },
    {
        name: "welcome",
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => {
                const on = (args[0] || "").toLowerCase();
                if (!["on", "off"].includes(on)) return say(sock, from, msg, `Usage: ${config.PREFIX}welcome on | off\nCurrently: *${groupSettings.get(from, "welcome", false) ? "ON" : "OFF"}*`);
                groupSettings.set(from, "welcome", on === "on");
                await say(sock, from, msg, `👋 Welcome messages: *${on.toUpperCase()}*`);
            }, { needBotAdmin: false });
        }
    },
    {
        name: "goodbye",
        async execute(sock, from, args, msg, extra = {}) {
            await guarded(sock, from, msg, extra, async () => {
                const on = (args[0] || "").toLowerCase();
                if (!["on", "off"].includes(on)) return say(sock, from, msg, `Usage: ${config.PREFIX}goodbye on | off\nCurrently: *${groupSettings.get(from, "goodbye", false) ? "ON" : "OFF"}*`);
                groupSettings.set(from, "goodbye", on === "on");
                await say(sock, from, msg, `👋 Goodbye messages: *${on.toUpperCase()}*`);
            }, { needBotAdmin: false });
        }
    },
    {
        name: "leave",
        async execute(sock, from, args, msg, extra = {}) {
            if (!from.endsWith("@g.us")) return say(sock, from, msg, "❌ This command only works in groups.");
            if (!isOwner(extra.sender, extra)) return say(sock, from, msg, "❌ Owner only.");
            await say(sock, from, msg, "👋 Goodbye everyone!");
            await sock.groupLeave(from);
        }
    }
];
