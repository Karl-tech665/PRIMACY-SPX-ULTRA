// Adapter for Cyntron-X command modules inside PRIMACY's multi-session handler.
const path = require("path");
const ownConfig = require("../config/config");
const ownAuth = require("../utils/auth");
const vendorRoot = path.join(__dirname, "../vendor/cyntron");
const vendorConfig = require(path.join(vendorRoot, "config.js"));
const vendorDb = require(path.join(vendorRoot, "database.js"));
const { loadCommands } = require(path.join(vendorRoot, "utils/commandLoader.js"));

vendorConfig.ownerNumber = [String(ownConfig.OWNER_NUMBER || "")];
vendorConfig.ownerName = [ownConfig.OWNER_NAME || "PRIMACY"];
vendorConfig.botName = ownConfig.BOT_NAME;
vendorConfig.prefix = ownConfig.PREFIX;
vendorConfig.social = Object.assign({}, vendorConfig.social || {}, { github: `https://github.com/${ownConfig.GITHUB_USER}/${ownConfig.GITHUB_REPO}` });

const friendRegistry = loadCommands();
const blocked = new Set(["cat", "viewonce", "vv", "vv2", "rvo", "readvo", "readviewonce", "getsession", "sessionid", "mysession", "setprefix", "prefix", "mode", "botmode", "setmode", "menu", "help", "cmds", "commands", "repo", "repository", "script", "source", "bomb"]);
const unique = [...new Set(friendRegistry.values())].filter(c => c && c.name && typeof c.execute === "function" && !blocked.has(String(c.name).toLowerCase()));

function cleanJid(v) { return String(v || "").split("@")[0].split(":")[0]; }
async function makeExtra(sock, from, msg, ownExtra, cmdName) {
  const sender = ownExtra.sender || msg?.key?.participant || msg?.key?.remoteJid;
  const isGroup = !!ownExtra.isGroup;
  let groupMetadata = null;
  if (isGroup) { try { groupMetadata = await sock.groupMetadata(from); } catch (_) {} }
  const isOwner = ownAuth.isOwner(sender, ownExtra);
  let isAdmin = false, isBotAdmin = false;
  if (isGroup && groupMetadata?.participants) {
    const participant = groupMetadata.participants.find(p => [p.id,p.jid,p.lid,p.phoneNumber].filter(Boolean).some(x => cleanJid(x) === cleanJid(sender)));
    isAdmin = !!(participant && (participant.admin === "admin" || participant.admin === "superadmin"));
    const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(cleanJid);
    const botParticipant = groupMetadata.participants.find(p => [p.id,p.jid,p.lid,p.phoneNumber].filter(Boolean).some(x => botIds.includes(cleanJid(x))));
    isBotAdmin = !!(botParticipant && (botParticipant.admin === "admin" || botParticipant.admin === "superadmin"));
  }
  const isMod = isOwner || (() => { try { return vendorDb.isModerator(sender); } catch (_) { return false; } })();
  const extra = {
    from, sender, isGroup, groupMetadata, groupName: groupMetadata?.subject || null,
    isOwner, isAdmin, isBotAdmin, isMod, isSudo: isMod,
    prefix: ownExtra.prefix || ownConfig.PREFIX, command: cmdName,
    triggerLabel: "Manual command", forwardToSelf: false,
    getCommandCount: () => friendRegistry.size,
    reply: text => sock.sendMessage(from, { text: String(text) }, { quoted: msg }),
    react: emoji => sock.sendMessage(from, { react: { text: emoji, key: msg.key } })
  };
  return extra;
}

module.exports = unique.map(cmd => ({
  name: cmd.name,
  aliases: (cmd.aliases || []).filter(a => !blocked.has(String(a).toLowerCase())),
  category: String(cmd.category || "general").toUpperCase(),
  description: cmd.description || "Imported command",
  async execute(sock, from, args, msg, ownExtra = {}) {
    const extra = await makeExtra(sock, from, msg, ownExtra, cmd.name);
    const cfgPrefix = extra.prefix || ".";
    if (cmd.ownerOnly && !extra.isOwner && !extra.isSudo) return extra.reply("👑 This command is only for the paired owner/developer.");
    if (cmd.groupOnly && !extra.isGroup) return extra.reply("👥 This command can only be used in groups.");
    if (cmd.privateOnly && extra.isGroup) return extra.reply("💬 This command can only be used privately.");
    if (cmd.adminOnly && !extra.isAdmin && !extra.isOwner) return extra.reply("🛡️ This command is only for group admins.");
    if (cmd.botAdminOnly && !extra.isBotAdmin) return extra.reply("🚫 The bot needs to be a group admin first.");
    vendorConfig.prefix = cfgPrefix;
    vendorConfig.ownerNumber = [String(ownConfig.OWNER_NUMBER || ""), String(ownExtra.sessionOwner || "")].filter(Boolean);
    return cmd.execute(sock, msg, args, extra);
  }
}));
