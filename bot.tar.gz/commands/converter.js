const config = require("../config/config");
const { getMediaTarget, download, unwrap } = require("../utils/media");

const say = (sock, from, msg, text) => sock.sendMessage(from, { text }, { quoted: msg });
const needMedia = (sock, from, msg, what) => say(sock, from, msg, `❌ Send or reply to ${what} with ${config.PREFIX}${msg.__cmd || "this command"}.`);

async function grab(sock, from, msg, kinds, label, cmd) {
    const t = getMediaTarget(msg);
    if (!t || !kinds.includes(t.kind)) {
        await say(sock, from, msg, `❌ Reply to ${label} with *${config.PREFIX}${cmd}*.`);
        return null;
    }
    return { t, buf: await download(sock, t) };
}

module.exports = [
    {
        name: "sticker", aliases: ["s", "stiker"],
        async execute(sock, from, args, msg) {
            try {
                const g = await grab(sock, from, msg, ["image", "video"], "a photo (or short video)", "sticker");
                if (!g) return;
                if (g.t.kind === "video") return say(sock, from, msg, "❌ Video stickers need extra software that this free server does not have. Please use a photo.");
                const { Sticker, StickerTypes } = require("wa-sticker-formatter");
                const st = new Sticker(g.buf, { pack: args.join(" ") || config.BOT_NAME, author: config.OWNER_NAME, type: StickerTypes.FULL, quality: 70 });
                await sock.sendMessage(from, await st.toMessage(), { quoted: msg });
            } catch (e) { console.log("sticker failed:", e.message); await say(sock, from, msg, "❌ Could not make the sticker. Try a different photo."); }
        }
    },
    {
        name: "toimg", aliases: ["toimage", "photo"],
        async execute(sock, from, args, msg) {
            try {
                const g = await grab(sock, from, msg, ["sticker"], "a sticker", "toimg");
                if (!g) return;
                if (g.t.node.isAnimated) return say(sock, from, msg, "❌ Animated stickers can't be converted to a photo.");
                const png = await require("sharp")(g.buf).png().toBuffer();
                await sock.sendMessage(from, { image: png, caption: "✅ Done" }, { quoted: msg });
            } catch (e) { console.log("toimg failed:", e.message); await say(sock, from, msg, "❌ Could not convert that sticker."); }
        }
    },
    {
        name: "blur",
        async execute(sock, from, args, msg) {
            try {
                const g = await grab(sock, from, msg, ["image"], "a photo", "blur");
                if (!g) return;
                const level = Math.min(Math.max(parseInt(args[0], 10) || 12, 1), 60);
                const out = await require("sharp")(g.buf).blur(level).jpeg().toBuffer();
                await sock.sendMessage(from, { image: out, caption: `🌫️ Blur ${level}` }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not blur that photo."); }
        }
    },
    {
        name: "grayscale", aliases: ["bw", "greyscale"],
        async execute(sock, from, args, msg) {
            try {
                const g = await grab(sock, from, msg, ["image"], "a photo", "grayscale");
                if (!g) return;
                const out = await require("sharp")(g.buf).grayscale().jpeg().toBuffer();
                await sock.sendMessage(from, { image: out, caption: "⚫⚪ Black & white" }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not edit that photo."); }
        }
    },
    {
        name: "invert", aliases: ["negative"],
        async execute(sock, from, args, msg) {
            try {
                const g = await grab(sock, from, msg, ["image"], "a photo", "invert");
                if (!g) return;
                const out = await require("sharp")(g.buf).negate().jpeg().toBuffer();
                await sock.sendMessage(from, { image: out, caption: "🎞️ Negative" }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not edit that photo."); }
        }
    },
    {
        name: "tourl", aliases: ["upload", "url"],
        async execute(sock, from, args, msg) {
            try {
                const g = await grab(sock, from, msg, ["image", "video", "audio", "sticker", "document"], "a file", "tourl");
                if (!g) return;
                const mime = g.t.node.mimetype || "application/octet-stream";
                const ext = (mime.split("/")[1] || "bin").split(";")[0];
                const form = new FormData();
                form.append("reqtype", "fileupload");
                form.append("fileToUpload", new Blob([g.buf], { type: mime }), `file.${ext}`);
                const r = await fetch("https://catbox.moe/user/api.php", { method: "POST", body: form });
                const link = (await r.text()).trim();
                if (!/^https?:\/\//.test(link)) throw new Error(link);
                await say(sock, from, msg, `🔗 *Your link:*\n${link}`);
            } catch (e) { console.log("tourl failed:", e.message); await say(sock, from, msg, "❌ Upload failed. The file may be too large (max about 200 MB) or the host is busy."); }
        }
    }
];
