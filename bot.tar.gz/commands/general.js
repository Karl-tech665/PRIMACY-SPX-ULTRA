const config = require("../config/config");
const { getBuffer } = require("../utils/net");
const { box, jidNum, textFrom } = require("../utils/helpers");

const say = (sock, from, msg, text, extra = {}) => sock.sendMessage(from, { text, ...extra }, { quoted: msg });

// Google's voice service only accepts about 200 characters at a time, so long text is cut into
// pieces at word boundaries and the audio pieces are joined together.
function splitForSpeech(text, size = 180) {
    const parts = [];
    let current = "";
    for (const word of text.replace(/\s+/g, " ").trim().split(" ")) {
        if (word.length > size) {
            if (current) { parts.push(current); current = ""; }
            for (let i = 0; i < word.length; i += size) parts.push(word.slice(i, i + size));
        } else if ((current + " " + word).trim().length > size) {
            parts.push(current);
            current = word;
        } else {
            current = (current + " " + word).trim();
        }
    }
    if (current) parts.push(current);
    return parts;
}

module.exports = [
    {
        name: "owner", aliases: ["dev", "creator"],
        async execute(sock, from, args, msg, extra = {}) {
            await say(sock, from, msg, box("OWNERSHIP", [
                `👑 *Developer:* ${config.OWNER_NAME}`, `📞 *Contact:* wa.me/${config.OWNER_NUMBER}`, `📱 *Session owner:* ${extra.sessionOwner || "Unknown"}`
            ]));
        }
    },
    {
        // Text to speech: the bot reads your text out loud as an audio message
        name: "say", aliases: ["voice"],
        async execute(sock, from, args, msg) {
            const words = [...args];
            let lang = "en";
            // Optional language code first, e.g.  .say sw habari za asubuhi
            if (words.length > 1 && /^[a-z]{2}(-[a-z]{2})?$/i.test(words[0])) lang = words.shift().toLowerCase();
            const text = words.join(" ") || textFrom([], msg);
            if (!text) {
                return say(sock, from, msg,
                    `🗣️ *Text to speech*\n\n${config.PREFIX}say hello everyone\n${config.PREFIX}say sw habari za asubuhi\n${config.PREFIX}say fr bonjour\n\nYou can also reply to a message with ${config.PREFIX}say.\n_Language codes: en, sw, fr, es, de, pt, ar, hi, it, ja, ko, zh..._`);
            }
            try {
                try { await sock.sendPresenceUpdate("recording", from); } catch (e) {}
                const pieces = splitForSpeech(text).slice(0, 5); // about 900 characters at most
                const buffers = [];
                for (const piece of pieces) {
                    buffers.push(await getBuffer(`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(piece)}`));
                }
                const audio = Buffer.concat(buffers);
                if (audio.length < 500) throw new Error("empty audio");
                await sock.sendMessage(from, { audio, mimetype: "audio/mpeg", ptt: false }, { quoted: msg });
            } catch (e) {
                console.log("say failed:", e.message);
                await say(sock, from, msg, "❌ I couldn't create the voice message right now. Check the language code (en, sw, fr...) or try again in a moment.");
            }
        }
    },
    {
        name: "calc", aliases: ["calculate", "math"],
        async execute(sock, from, args, msg) {
            if (!args.length) return say(sock, from, msg, `❌ ${config.PREFIX}calc 2+2*5`);
            const exp = args.join(" ").replace(/[x×]/gi, "*").replace(/÷/g, "/").replace(/\^/g, "**").replace(/[^0-9+\-*/().% ]/g, "");
            if (!exp.trim()) return say(sock, from, msg, "❌ Invalid expression.");
            try {
                const r = Function('"use strict"; return (' + exp + ")")();
                if (typeof r !== "number" || !isFinite(r)) throw new Error("bad");
                await say(sock, from, msg, `🧮 *${exp}* = *${r}*`);
            } catch (e) { await say(sock, from, msg, "❌ Invalid expression."); }
        }
    },
    {
        name: "id", aliases: ["jid"],
        async execute(sock, from, args, msg, extra = {}) {
            await say(sock, from, msg, box("IDS", [`💬 *Chat:* ${from}`, `👤 *You:* ${jidNum(extra.sender)}`, extra.isGroup ? "👥 This is a group" : "👤 Private chat"]));
        }
    }
];
