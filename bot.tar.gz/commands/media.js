const axios = require("axios");
const ytdl = require("@distube/ytdl-core");
const yts = require("yt-search");
const config = require("../config/config");
const { getBuffer } = require("../utils/net");
const { box, clip } = require("../utils/helpers");

const say = (sock, from, msg, text) => sock.sendMessage(from, { text }, { quoted: msg });
const usage = (sock, from, msg, u) => say(sock, from, msg, `❌ Usage: ${config.PREFIX}${u}`);
const MAX_SECONDS = 20 * 60; // refuse very long videos so the free server is not overloaded

async function firstVideo(query) {
    const r = await yts(query);
    return r.videos?.[0];
}

async function streamToBuffer(stream, limitBytes = 60 * 1024 * 1024) {
    const chunks = [];
    let size = 0;
    for await (const c of stream) {
        size += c.length;
        if (size > limitBytes) throw new Error("File is too large to send");
        chunks.push(c);
    }
    return Buffer.concat(chunks);
}

module.exports = [
    {
        name: "play", aliases: ["ytaudio", "song", "ytmp3"],
        async execute(sock, from, args, msg) {
            const q = args.join(" ");
            if (!q) return usage(sock, from, msg, "play <song name or YouTube link>");
            try {
                try { await sock.sendPresenceUpdate("recording", from); } catch (e) {}
                const v = /^https?:\/\//i.test(q) ? { url: q, title: q, seconds: 0 } : await firstVideo(q);
                if (!v) return say(sock, from, msg, "❌ No results found.");
                if (v.seconds && v.seconds > MAX_SECONDS) return say(sock, from, msg, "❌ That track is longer than 20 minutes. Please pick a shorter one.");
                await say(sock, from, msg, `⬇️ *${v.title}*${v.timestamp ? `  (${v.timestamp})` : ""}\n⏳ Downloading, please wait...`);
                const buf = await streamToBuffer(ytdl(v.url, { filter: "audioonly", quality: "highestaudio" }));
                await sock.sendMessage(from, { audio: buf, mimetype: "audio/mp4", fileName: `${v.title}.mp3` }, { quoted: msg });
            } catch (e) {
                console.log("play failed:", e.message);
                await say(sock, from, msg, "❌ I couldn't download that. YouTube sometimes blocks free servers, so try another song or try again in a few minutes.");
            }
        }
    },
    {
        name: "ytvideo", aliases: ["video", "ytmp4"],
        async execute(sock, from, args, msg) {
            const q = args.join(" ");
            if (!q) return usage(sock, from, msg, "ytvideo <video name or YouTube link>");
            try {
                const v = /^https?:\/\//i.test(q) ? { url: q, title: q, seconds: 0 } : await firstVideo(q);
                if (!v) return say(sock, from, msg, "❌ No results found.");
                if (v.seconds && v.seconds > 600) return say(sock, from, msg, "❌ Videos longer than 10 minutes are not supported.");
                await say(sock, from, msg, `⬇️ *${v.title}*\n⏳ Downloading video, please wait...`);
                const buf = await streamToBuffer(ytdl(v.url, { quality: "lowest", filter: "audioandvideo" }));
                await sock.sendMessage(from, { video: buf, caption: `🎬 ${clip(v.title, 200)}` }, { quoted: msg });
            } catch (e) {
                console.log("ytvideo failed:", e.message);
                await say(sock, from, msg, "❌ I couldn't download that video. Try another one or try again later.");
            }
        }
    },
    {
        name: "yts", aliases: ["ytsearch", "youtube"],
        async execute(sock, from, args, msg) {
            const q = args.join(" ");
            if (!q) return usage(sock, from, msg, "yts <search>");
            try {
                const r = (await yts(q)).videos.slice(0, 5);
                if (!r.length) return say(sock, from, msg, "❌ No results found.");
                await say(sock, from, msg, `🔍 *YouTube results for "${q}"*\n\n` + r.map((v, i) => `*${i + 1}. ${v.title}*\n⏱️ ${v.timestamp}  👀 ${v.views.toLocaleString("en-US")}\n🔗 ${v.url}`).join("\n\n"));
            } catch (e) { await say(sock, from, msg, "❌ Search failed. Try again shortly."); }
        }
    },
    {
        name: "tiktok", aliases: ["tt", "tiktokdl"],
        async execute(sock, from, args, msg) {
            const url = args[0];
            if (!/^https?:\/\//i.test(url || "")) return usage(sock, from, msg, "tiktok <TikTok link>");
            try {
                const r = await axios.post("https://www.tikwm.com/api/", new URLSearchParams({ url, hd: "1" }).toString(), { timeout: 30000, headers: { "Content-Type": "application/x-www-form-urlencoded" } });
                const d = r.data?.data;
                let v = d?.hdplay || d?.play;
                if (!v) throw new Error(r.data?.msg || "no video");
                if (v.startsWith("/")) v = "https://www.tikwm.com" + v;
                const buf = await getBuffer(v);
                await sock.sendMessage(from, { video: buf, caption: `📱 *${clip(d.title || "TikTok", 200)}*\n👤 ${d.author?.nickname || ""}` }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not download that TikTok. Make sure the link is public and try again."); }
        }
    },
    {
        name: "instagram", aliases: ["ig", "igdl"],
        async execute(sock, from, args, msg) {
            const url = args[0];
            if (!/^https?:\/\//i.test(url || "")) return usage(sock, from, msg, "instagram <post or reel link>");
            try {
                const s = require("@bochilteam/scraper");
                const fn = s.instagramdl || s.instagram;
                if (!fn) throw new Error("not available");
                const r = await fn(url);
                const list = Array.isArray(r) ? r : (r.media || r.video ? [].concat(r.media || r.video) : []);
                const item = list[0];
                const link = typeof item === "string" ? item : (item?.url || item?.link);
                if (!link) throw new Error("no media");
                const isVideo = /\.mp4/i.test(link);
                await sock.sendMessage(from, { [isVideo ? "video" : "image"]: { url: link }, caption: "📸 Instagram" }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Instagram downloads are unreliable (Instagram blocks bots). Try another link or try again later."); }
        }
    },
    {
        name: "facebook", aliases: ["fb", "fbdl"],
        async execute(sock, from, args, msg) {
            const url = args[0];
            if (!/^https?:\/\//i.test(url || "")) return usage(sock, from, msg, "facebook <video link>");
            try {
                const s = require("@bochilteam/scraper");
                const fn = s.facebookdl || s.facebook;
                if (!fn) throw new Error("not available");
                const r = await fn(url);
                const v = r.hd || r.sd || r.result?.[0]?.url || (Array.isArray(r) ? (r[0]?.url || r[0]) : null);
                if (!v) throw new Error("no media");
                await sock.sendMessage(from, { video: { url: typeof v === "string" ? v : v.url }, caption: "📘 Facebook" }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Facebook downloads are unreliable. Make sure the video is public, or try again later."); }
        }
    },
    {
        name: "gitclone",
        async execute(sock, from, args, msg) {
            if (!args.length) return usage(sock, from, msg, "gitclone https://github.com/user/repo");
            try {
                const m = args[0].match(/github\.com\/([^/\s]+)\/([^/\s#?]+)/i);
                if (!m) throw new Error("bad link");
                const owner = m[1], repo = m[2].replace(/\.git$/, "");
                const info = (await axios.get(`https://api.github.com/repos/${owner}/${repo}`, { timeout: 20000 })).data;
                const zip = await getBuffer(`https://github.com/${owner}/${repo}/archive/refs/heads/${info.default_branch}.zip`);
                await sock.sendMessage(from, { document: zip, mimetype: "application/zip", fileName: `${repo}.zip`, caption: `📦 *${info.full_name}*\n⭐ ${info.stargazers_count}  🍴 ${info.forks_count}` }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not download that repository. Check the link."); }
        }
    }
];
