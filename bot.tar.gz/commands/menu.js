const config = require("../config/config");
const settingsStore = require("../utils/settingsStore");
const { formatUptime, getRAMUsage, getSpeed, readImage } = require("../utils/helpers");

// Order and heading of each section in the menu (a section that is not listed is added at the end)
const ORDER = ["BASIC", "GENERAL", "AI", "FUN", "ANIME", "TOOLS", "DOWNLOADER", "CONVERTER", "GROUP", "ADMIN", "REPO", "MENU"];
const TITLES = {
    BASIC: "BASIC-CMD", GENERAL: "GEN-CMD", AI: "AI-CMD", FUN: "FUN-CMD", ANIME: "ANIME-CMD", TOOLS: "TOOLS-CMD",
    DOWNLOADER: "DOWNLOAD-CMD", CONVERTER: "CONVERT-CMD", GROUP: "GROUP-CMD", ADMIN: "ADMIN-CMD", REPO: "REPO-CMD", MENU: "MENU-CMD"
};
const titleOf = (cat) => TITLES[cat] || `${cat}-CMD`;

function groupCommands(registry) {
    const groups = new Map();
    const unique = registry && registry.values ? [...new Set(registry.values())] : [];
    for (const cmd of unique) {
        if (cmd.hidden) continue;
        const cat = cmd.category || "GENERAL";
        if (!groups.has(cat)) groups.set(cat, []);
        groups.get(cat).push(cmd.name);
    }
    for (const names of groups.values()) names.sort();
    const known = ORDER.filter(c => groups.has(c));
    const extra = [...groups.keys()].filter(c => !ORDER.includes(c)).sort();
    return { groups, order: [...known, ...extra] };
}

function section(cat, names) {
    return `┌❏ *${titleOf(cat)}* ◈\n` + names.map(n => `│ ◈ ${n}`).join("\n") + `\n└❏`;
}

function platformName() {
    if (process.env.RENDER) return "Render";
    if (process.env.DYNO) return "Heroku";
    if (process.env.RAILWAY_ENVIRONMENT) return "Railway";
    if (process.env.KOYEB_APP_NAME) return "Koyeb";
    return process.platform === "linux" ? "Linux" : process.platform;
}

// How long the message took to reach the bot; falls back to a quick self-test if the clocks disagree
async function speedMs(msg) {
    const t = msg?.messageTimestamp;
    const seconds = t && typeof t === "object" && t.toNumber ? t.toNumber() : Number(t);
    const ms = Date.now() - seconds * 1000;
    if (ms >= 0 && ms < 60000) return Math.round(ms);
    return parseInt(await getSpeed(), 10) || 0;
}

module.exports = {
    name: "menu", aliases: ["help", "cmds", "commands"],
    async execute(sock, from, args, msg, extra = {}) {
        const prefix = config.PREFIX;
        const { groups, order } = groupCommands(extra.commands);
        const total = [...groups.values()].reduce((n, names) => n + names.length, 0);

        // ".menu ai" shows just one section, ".menu list" shows the section names
        const ask = (args[0] || "").toUpperCase();
        if (ask === "LIST") {
            return sock.sendMessage(from, { text: `┌❏ *MENU SECTIONS* ◈\n${order.map(c => `│ ◈ ${prefix}menu ${c.toLowerCase()}  (${groups.get(c).length})`).join("\n")}\n└❏` }, { quoted: msg });
        }
        if (ask) {
            if (!groups.has(ask)) return sock.sendMessage(from, { text: `No section called *${args[0]}*.\nType *${prefix}menu list* to see them all.` }, { quoted: msg });
            return sock.sendMessage(from, { text: `${section(ask, groups.get(ask))}\n\nPowered by ${config.FOOTER_BRAND}` }, { quoted: msg });
        }

        const mode = String(settingsStore.get(`${extra.sessionOwner}_mode`, config.MODE));
        const ram = getRAMUsage();
        const barFilled = Math.min(10, Math.round(ram.percent / 10));
        const bar = "█".repeat(barFilled) + "░".repeat(10 - barFilled);

        const header = [
            `┌❏ *${config.BOT_NAME}* ◈`,
            `│ *PREFIX:* [ ${prefix} ]`,
            `│ *OWNER:* ${config.OWNER_NAME}`,
            `│ *MODE:* ${mode.charAt(0).toUpperCase() + mode.slice(1).toLowerCase()}`,
            `│ *PLATFORM:* ${platformName()}`,
            `│ *SPEED:* ${await speedMs(msg)} ms`,
            `│ *UPTIME:* ${formatUptime()}`,
            `│ *VERSION:* v${config.VERSION}`,
            `│ *USAGE:* ${ram.used} MB of ${ram.total} MB`,
            `│ *RAM:* [${bar}] ${ram.percent}%`,
            `│ *COMMANDS:* ${total}`,
            `└❏`
        ].join("\n");

        const body = order.map(c => section(c, groups.get(c))).join("\n\n") +
            `\n\nSections: ${prefix}menu list  |  One section: ${prefix}menu ai` +
            `\nRepo: https://github.com/${config.GITHUB_USER}/${config.GITHUB_REPO}` +
            `\n\nPowered by ${config.FOOTER_BRAND}`;

        // Banner picture (stored in the repo, so it never fails to load) with the info box as its caption
        const img = readImage(config.MENU_IMAGE);
        let imageSent = false;
        if (img) {
            try { await sock.sendMessage(from, { image: img, caption: header }, { quoted: msg }); imageSent = true; }
            catch (e) { console.log("Menu image failed:", e.message); }
        }
        await sock.sendMessage(from, { text: imageSent ? body : `${header}\n\n${body}` }, imageSent ? undefined : { quoted: msg });
    }
};
