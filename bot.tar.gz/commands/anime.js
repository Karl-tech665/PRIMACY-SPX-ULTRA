const config = require("../config/config");
const { getJson } = require("../utils/net");
const { jidNum } = require("../utils/helpers");

// Pictures and reactions from the free waifu.pics service (safe-for-work only)
const PICTURES = ["waifu", "neko", "shinobu", "megumin", "awoo"];

// [command, what it says]
const REACTIONS = [
    ["hug", "hugs"], ["kiss", "kisses"], ["pat", "pats"], ["slap", "slaps"], ["cuddle", "cuddles"], ["bonk", "bonks"],
    ["bite", "bites"], ["lick", "licks"], ["poke", "pokes"], ["highfive", "high-fives"], ["handhold", "holds hands with"],
    ["glomp", "glomps"], ["yeet", "yeets"], ["bully", "bullies"], ["nom", "nibbles"], ["kill", "defeats"]
];
const MOODS = [["cry", "is crying"], ["smug", "is feeling smug"], ["blush", "is blushing"], ["smile", "is smiling"], ["wave", "is waving"], ["happy", "is happy"], ["wink", "winks"], ["dance", "is dancing"], ["cringe", "is cringing"]];

async function fetchPicture(kind) {
    const d = await getJson(`https://api.waifu.pics/sfw/${kind}`);
    if (!d || !d.url) throw new Error("no picture");
    return d.url;
}

async function sendPicture(sock, from, msg, url, caption, mentions) {
    try { await sock.sendMessage(from, { image: { url }, caption, mentions }, { quoted: msg }); }
    catch (e) { await sock.sendMessage(from, { text: `${caption}\n${url}`, mentions }, { quoted: msg }); }
}

const commands = [];

for (const kind of PICTURES) {
    commands.push({
        name: kind,
        async execute(sock, from, args, msg) {
            try { await sendPicture(sock, from, msg, await fetchPicture(kind), `✨ ${kind.toUpperCase()}`); }
            catch (e) { await sock.sendMessage(from, { text: "❌ The picture service is busy. Try again in a moment." }, { quoted: msg }); }
        }
    });
}

function actor(msg) { return msg.key.participant || msg.key.remoteJid; }
function target(msg) {
    const ctx = msg.message?.extendedTextMessage?.contextInfo;
    return ctx?.mentionedJid?.[0] || ctx?.participant || null;
}

for (const [kind, verb] of REACTIONS) {
    commands.push({
        name: kind,
        async execute(sock, from, args, msg) {
            const a = actor(msg), t = target(msg);
            if (!t) return sock.sendMessage(from, { text: `❌ Reply to someone or mention them: ${config.PREFIX}${kind} @user` }, { quoted: msg });
            try { await sendPicture(sock, from, msg, await fetchPicture(kind), `💫 @${jidNum(a)} ${verb} @${jidNum(t)}`, [a, t]); }
            catch (e) { await sock.sendMessage(from, { text: `💫 @${jidNum(a)} ${verb} @${jidNum(t)}`, mentions: [a, t] }, { quoted: msg }); }
        }
    });
}

for (const [kind, verb] of MOODS) {
    commands.push({
        name: kind,
        async execute(sock, from, args, msg) {
            const a = actor(msg);
            try { await sendPicture(sock, from, msg, await fetchPicture(kind), `💫 @${jidNum(a)} ${verb}`, [a]); }
            catch (e) { await sock.sendMessage(from, { text: `💫 @${jidNum(a)} ${verb}`, mentions: [a] }, { quoted: msg }); }
        }
    });
}

module.exports = commands;
