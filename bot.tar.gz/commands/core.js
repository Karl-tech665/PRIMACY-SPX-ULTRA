const config = require("../config/config");
const { formatUptime, getRAMUsage, readImage, box } = require("../utils/helpers");

const say = (sock, from, msg, text) => sock.sendMessage(from, { text }, { quoted: msg });

module.exports = [
    {
        name: "ping", aliases: ["speed"],
        async execute(sock, from, args, msg) {
            const t = Date.now();
            const sent = await sock.sendMessage(from, { text: "⚡ *Pinging...*" }, { quoted: msg });
            const ms = Date.now() - t;
            try { await sock.sendMessage(from, { text: `🚀 *Pong!* ${ms}ms`, edit: sent.key }); }
            catch (e) { await say(sock, from, msg, `🚀 *Pong!* ${ms}ms`); }
        }
    },
    {
        name: "alive", aliases: ["status", "bot"],
        async execute(sock, from, args, msg, extra = {}) {
            const ram = getRAMUsage();
            const total = extra.commands ? new Set(extra.commands.values()).size : 0;
            const caption = box("BOT STATUS", [
                "🟢 *Status:* Online", `🤖 *Name:* ${config.BOT_NAME}`, `📦 *Version:* ${config.VERSION}`,
                `⏱️ *Uptime:* ${formatUptime()}`, `🧠 *RAM:* ${ram.used}MB / ${ram.total}MB`, `📂 *Commands:* ${total}`
            ]) + `\n\nType *${config.PREFIX}menu* for all commands.`;
            const img = readImage(config.MENU_IMAGE);
            if (img) { try { return await sock.sendMessage(from, { image: img, caption }, { quoted: msg }); } catch (e) {} }
            await say(sock, from, msg, caption);
        }
    },
    {
        name: "botinfo", aliases: ["info"],
        async execute(sock, from, args, msg, extra = {}) {
            const total = extra.commands ? new Set(extra.commands.values()).size : 0;
            await say(sock, from, msg, box("BOT INFO", [
                `🤖 *Name:* ${config.BOT_NAME}`, `👑 *Owner:* ${config.OWNER_NAME}`, `📦 *Commands:* ${total}`, `⚙️ *Prefix:* ${config.PREFIX}`,
                `🏷️ *Version:* ${config.VERSION}`, `🛠️ *Runtime:* Node ${process.version}`, `📚 *Library:* Baileys (multi-device)`
            ]));
        }
    },
    {
        name: "uptime", aliases: ["runtime"],
        async execute(sock, from, args, msg) { await say(sock, from, msg, `⏱️ *Uptime:* ${formatUptime()}`); }
    },
    {
        name: "time", aliases: ["date"],
        async execute(sock, from, args, msg) {
            const tz = process.env.TIMEZONE || "Africa/Nairobi";
            let text;
            try { text = new Date().toLocaleString("en-GB", { timeZone: tz, dateStyle: "full", timeStyle: "medium" }); }
            catch (e) { text = new Date().toISOString(); }
            await say(sock, from, msg, `🕐 *${text}*\n🌍 _${tz}_`);
        }
    },
    {
        name: "proxy",
        async execute(sock, from, args, msg) {
            await say(sock, from, msg, box("TELEGRAM-STYLE PROXY", [`🌐 *Connect:* ${config.PROXY.LINK}`, `🔗 *Website:* ${config.PROXY.WEBSITE}`]) + "\n\nTap the link on your phone to add the proxy to WhatsApp.");
        }
    }
];
