const config = require("../config/config");
const { ask, imageUrl } = require("../utils/ai");
const { getBuffer } = require("../utils/net");
const { textFrom, clip } = require("../utils/helpers");

const memory = new Map(); // chat id -> recent conversation for .prime

async function think(sock, from) { try { await sock.sendPresenceUpdate("composing", from); } catch (e) {} }

function simple(name, aliases, icon, instruction, usage) {
    return {
        name, aliases,
        async execute(sock, from, args, msg) {
            const text = textFrom(args, msg);
            if (!text) return sock.sendMessage(from, { text: `❌ Usage: ${config.PREFIX}${name} ${usage}\n(or reply to a message with ${config.PREFIX}${name})` }, { quoted: msg });
            await think(sock, from);
            try {
                const r = await ask(`${instruction}\n\n${text}`, { system: "You are a helpful assistant replying inside WhatsApp. Be concise." });
                await sock.sendMessage(from, { text: `${icon} ${clip(r.text)}` }, { quoted: msg });
            } catch (e) { await sock.sendMessage(from, { text: `❌ ${e.message}` }, { quoted: msg }); }
        }
    };
}

module.exports = [
    {
        name: "ai", aliases: ["gpt", "gemini", "chatgpt", "ask"],
        async execute(sock, from, args, msg) {
            const q = textFrom(args, msg);
            if (!q) return sock.sendMessage(from, { text: `❌ Usage: ${config.PREFIX}ai <question>\nExample: ${config.PREFIX}ai explain how rainbows form` }, { quoted: msg });
            await think(sock, from);
            try {
                const r = await ask(q, { system: "You are a helpful assistant replying inside WhatsApp. Keep answers clear and reasonably short. Use *bold* for emphasis, not markdown headings." });
                await sock.sendMessage(from, { text: `🤖 ${clip(r.text)}` }, { quoted: msg });
            } catch (e) { await sock.sendMessage(from, { text: `❌ ${e.message}` }, { quoted: msg }); }
        }
    },

    {
        name: "prime", aliases: ["void"],
        async execute(sock, from, args, msg, extra = {}) {
            const q = textFrom(args, msg);
            if (!q) return sock.sendMessage(from, { text: `🐞 *Prime* here! I remember our conversation in this chat.\nAsk me anything, for example:\n${config.PREFIX}prime what can you do?\n${config.PREFIX}prime write a short poem about Nairobi\n\nUse ${config.PREFIX}clearchat to make me forget.` }, { quoted: msg });

            const names = [...new Set((extra.commands ? [...extra.commands.values()] : []).map(c => c.name))].sort();
            const system =
                `You are Prime 🐞, the friendly built-in assistant of the WhatsApp bot "${config.BOT_NAME}" (version ${config.VERSION}).\n` +
                `The command prefix is "${config.PREFIX}". The bot owner is ${config.OWNER_NAME}. The user can type ${config.PREFIX}menu to see all commands.\n` +
                `The bot currently has these commands: ${names.join(", ")}.\n` +
                `Answer questions about the bot using only that list. For everything else, answer like a smart, helpful friend. Keep replies short and WhatsApp-friendly; use *bold* sparingly and never use markdown headings.`;

            const history = memory.get(from) || [];
            await think(sock, from);
            try {
                const r = await ask(q, { system, history });
                history.push({ role: "user", text: q }, { role: "model", text: r.text });
                memory.set(from, history.slice(-12));
                if (memory.size > 200) memory.delete(memory.keys().next().value);
                await sock.sendMessage(from, { text: `🐞 ${clip(r.text)}` }, { quoted: msg });
            } catch (e) { await sock.sendMessage(from, { text: `❌ ${e.message}` }, { quoted: msg }); }
        }
    },

    {
        name: "clearchat", aliases: ["resetai", "forget"],
        async execute(sock, from, args, msg) {
            memory.delete(from);
            await sock.sendMessage(from, { text: "🧹 Done. Prime has forgotten this conversation." }, { quoted: msg });
        }
    },

    {
        name: "imagine", aliases: ["draw", "aiimg"],
        async execute(sock, from, args, msg) {
            const prompt = textFrom(args, msg);
            if (!prompt) return sock.sendMessage(from, { text: `❌ Usage: ${config.PREFIX}imagine <describe the picture>\nExample: ${config.PREFIX}imagine a lion wearing a crown, cartoon style` }, { quoted: msg });
            await sock.sendMessage(from, { text: "🎨 Creating your image, this can take up to a minute..." }, { quoted: msg });
            try {
                const buf = await getBuffer(await imageUrl(prompt), { timeout: 90000 });
                if (buf.length < 2000) throw new Error("The image service returned an empty file");
                await sock.sendMessage(from, { image: buf, caption: `🎨 *${clip(prompt, 200)}*` }, { quoted: msg });
            } catch (e) { await sock.sendMessage(from, { text: `❌ Could not create the image (${e.message}). Try again in a moment.` }, { quoted: msg }); }
        }
    },

    simple("summarize", ["tldr"], "📝", "Summarize the following text in a few short bullet points:", "<text>"),
    simple("grammar", ["fix", "correct"], "✍️", "Correct the grammar and spelling of the following text. Reply with only the corrected text:", "<text>"),
    simple("rephrase", ["paraphrase"], "🔁", "Rephrase the following text so it sounds natural and clear. Reply with only the new text:", "<text>"),
    simple("explain", ["eli5"], "💡", "Explain the following in simple words anyone can understand:", "<topic>"),
    simple("code", ["coder", "program"], "💻", "Write clean, working code for the following request, then explain it briefly:", "<what to build>")
];
