const axios = require("axios");
const config = require("../config/config");
const { readImage, box } = require("../utils/helpers");

const REPO_URL = `https://github.com/${config.GITHUB_USER}/${config.GITHUB_REPO}`;

module.exports = {
    name: "repo", aliases: ["repository", "script", "source"],
    async execute(sock, from, args, msg) {
        let stars = "-", forks = "-", updated = "-";
        try {
            // Live numbers from GitHub (if GitHub is slow the card still sends, just without them)
            const res = await axios.get(`https://api.github.com/repos/${config.GITHUB_USER}/${config.GITHUB_REPO}`, { timeout: 8000 });
            stars = res.data.stargazers_count;
            forks = res.data.forks_count;
            updated = new Date(res.data.updated_at).toLocaleDateString("en-GB");
        } catch (e) { console.log("GitHub API error:", e.message); }

        const caption = box("GITHUB REPOSITORY", [
            `🤖 *Bot:* ${config.BOT_NAME}`, `👑 *Dev:* ${config.OWNER_NAME}`,
            `⭐ *Stars:* ${stars}`, `🍴 *Forks:* ${forks}`, `📅 *Updated:* ${updated}`
        ]) + `\n\n🔗 *Link:*\n${REPO_URL}\n\n⭐ _Star and fork the project to support it!_`;

        // The picture lives in the repo (assets/repo.jpg), so it never fails to load
        const img = readImage(config.REPO_IMAGE);
        if (img) {
            try { return await sock.sendMessage(from, { image: img, caption }, { quoted: msg }); }
            catch (e) { console.log("Repo image failed:", e.message); }
        }
        await sock.sendMessage(from, { text: caption }, { quoted: msg });
    }
};
