const crypto = require("crypto");
const config = require("../config/config");
const { getJson } = require("../utils/net");
const { pick, box, jidNum, sleep } = require("../utils/helpers");

const say = (sock, from, msg, text, extra = {}) => sock.sendMessage(from, { text, ...extra }, { quoted: msg });

function targetOf(msg) {
    const ctx = msg.message?.extendedTextMessage?.contextInfo;
    return ctx?.mentionedJid?.[0] || ctx?.participant || null;
}

function decodeHtml(s) {
    const map = { "&quot;": '"', "&#039;": "'", "&amp;": "&", "&lt;": "<", "&gt;": ">", "&eacute;": "é", "&ouml;": "ö", "&uuml;": "ü", "&ntilde;": "ñ", "&rsquo;": "’", "&ldquo;": "“", "&rdquo;": "”", "&hellip;": "…" };
    return String(s).replace(/&[a-z]+;|&#\d+;/gi, m => map[m] || (m.startsWith("&#") ? String.fromCharCode(parseInt(m.slice(2, -1), 10)) : m));
}

// Local backups, so the commands still answer if a website is down
const JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs!",
    "Why did the scarecrow win an award? He was outstanding in his field!",
    "I told my computer I needed a break. Now it won't stop sending me vacation ads.",
    "Why don't skeletons fight each other? They don't have the guts.",
    "What do you call a fake noodle? An impasta!",
    "Why was the math book sad? It had too many problems.",
    "I'm reading a book about anti-gravity. It's impossible to put down!"
];
const FACTS = [
    "Honey never spoils. Edible honey has been found in ancient Egyptian tombs.",
    "Octopuses have three hearts and blue blood.",
    "A day on Venus is longer than a year on Venus.",
    "Bananas are berries, but strawberries are not.",
    "Kenya's Rift Valley is part of a rift that is slowly splitting the African continent.",
    "Your brain uses about 20% of your body's energy even though it is only 2% of its weight."
];
const QUOTES = [
    ["The only way to do great work is to love what you do.", "Steve Jobs"],
    ["It always seems impossible until it's done.", "Nelson Mandela"],
    ["Whether you think you can or you think you can't, you're right.", "Henry Ford"],
    ["Success is the sum of small efforts repeated day in and day out.", "Robert Collier"]
];
const BALL = ["Yes, definitely.", "It is certain.", "Without a doubt.", "Most likely.", "Signs point to yes.", "Ask again later.", "Cannot predict now.", "Don't count on it.", "My sources say no.", "Very doubtful.", "Absolutely not."];
const TRUTHS = [
    "What is the most embarrassing thing you have ever done?", "Who was your first crush?", "What is a secret talent nobody knows you have?",
    "What is the last lie you told?", "Which app do you spend the most time on?", "What is your biggest fear?",
    "Have you ever pretended to be sick to skip something?", "What is the worst gift you have ever received?", "Who in this chat would you swap lives with for a day?",
    "What is something you are afraid to tell your parents?", "What's the silliest thing you've cried about?", "What is your most-used emoji and why?"
];
const DARES = [
    "Send a voice note singing the chorus of your favourite song.", "Change your WhatsApp status to 'I love broccoli' for one hour.", "Text your best friend 'I know your secret' and screenshot the reply.",
    "Do 15 push-ups and send proof.", "Speak in an accent for the next 10 minutes.", "Send a selfie making your silliest face.",
    "Write a poem about the person above you in the chat.", "Send the 5th photo in your gallery without explaining it.", "Talk only in questions for the next 5 minutes.",
    "Say the alphabet backwards as fast as you can in a voice note."
];
const PICKUPS = [
    "Are you Wi-Fi? Because I'm feeling a strong connection.", "Do you have a map? I keep getting lost in your eyes.",
    "Is your name Google? Because you have everything I've been searching for.", "Are you a bank loan? Because you have my interest.",
    "Do you believe in love at first text, or should I message again?", "If you were a vegetable, you'd be a cute-cumber."
];
const COMPLIMENTS = [
    "You light up every chat you join. ✨", "Your energy is unmatched. 🔥", "You make hard things look easy. 💪",
    "You have a great sense of humour. 😄", "People are lucky to know you. 🌟", "You're a genius in the making. 🧠"
];
const ROASTS = [
    "You're the reason the shampoo bottle has instructions.", "I'd agree with you, but then we'd both be wrong.",
    "You bring everyone so much joy... when you leave the chat.", "If I wanted to hear from someone clueless, I'd just open my fridge at midnight.",
    "You have the confidence of a person who has never lost at Ludo, and the skills of one who always has."
];
const RIDDLES = [
    ["What has keys but can't open locks?", "A piano"], ["What gets wetter the more it dries?", "A towel"],
    ["What has hands but can't clap?", "A clock"], ["The more you take, the more you leave behind. What am I?", "Footsteps"],
    ["What can travel around the world while staying in a corner?", "A stamp"], ["I speak without a mouth and hear without ears. What am I?", "An echo"],
    ["What has a head and a tail but no body?", "A coin"], ["What month of the year has 28 days?", "All of them"]
];

async function pictureFrom(sock, from, msg, url, caption) {
    try { await sock.sendMessage(from, { image: { url }, caption }, { quoted: msg }); }
    catch (e) { await say(sock, from, msg, `${caption}\n${url}`); }
}

module.exports = [
    {
        name: "joke",
        async execute(sock, from, args, msg) {
            let text;
            try {
                const d = await getJson("https://v2.jokeapi.dev/joke/Programming,Misc,Pun?blacklistFlags=nsfw,religious,political,racist,sexist,explicit");
                text = d.type === "twopart" ? `${d.setup}\n\n👉 ${d.delivery}` : d.joke;
            } catch (e) { text = pick(JOKES); }
            await say(sock, from, msg, "😂 " + text);
        }
    },
    {
        name: "dadjoke",
        async execute(sock, from, args, msg) {
            let text;
            try { text = (await getJson("https://icanhazdadjoke.com/", { headers: { Accept: "application/json" } })).joke; } catch (e) { text = pick(JOKES); }
            await say(sock, from, msg, "👨 " + text);
        }
    },
    {
        name: "fact", aliases: ["funfact"],
        async execute(sock, from, args, msg) {
            let text;
            try { text = (await getJson("https://uselessfacts.jsph.pl/api/v2/facts/random?language=en")).text; } catch (e) { text = pick(FACTS); }
            await say(sock, from, msg, "🧠 *Did you know?*\n" + text);
        }
    },
    {
        name: "quote", aliases: ["inspire"],
        async execute(sock, from, args, msg) {
            let q, a;
            try { const d = await getJson("https://zenquotes.io/api/random"); q = d[0].q; a = d[0].a; } catch (e) { [q, a] = pick(QUOTES); }
            await say(sock, from, msg, `💬 _"${q}"_\n\n— *${a}*`);
        }
    },
    {
        name: "advice",
        async execute(sock, from, args, msg) {
            let text;
            try { text = (await getJson("https://api.adviceslip.com/advice")).slip.advice; } catch (e) { text = "Drink water, take a walk, and do one small thing today that your future self will thank you for."; }
            await say(sock, from, msg, "🧭 *Advice:* " + text);
        }
    },
    {
        name: "meme",
        async execute(sock, from, args, msg) {
            try {
                const d = await getJson("https://meme-api.com/gimme");
                await sock.sendMessage(from, { image: { url: d.url }, caption: "😂 " + d.title }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not fetch a meme right now. Try again in a moment."); }
        }
    },
    {
        name: "dog",
        async execute(sock, from, args, msg) {
            try { await pictureFrom(sock, from, msg, (await getJson("https://dog.ceo/api/breeds/image/random")).message, "🐶 Woof!"); }
            catch (e) { await say(sock, from, msg, "❌ No dogs available right now."); }
        }
    },
    {
        name: "cat",
        async execute(sock, from, args, msg) {
            try { await pictureFrom(sock, from, msg, (await getJson("https://api.thecatapi.com/v1/images/search"))[0].url, "🐱 Meow!"); }
            catch (e) { await say(sock, from, msg, "❌ No cats available right now."); }
        }
    },
    {
        name: "8ball", aliases: ["eightball"],
        async execute(sock, from, args, msg) {
            if (!args.length) return say(sock, from, msg, `❌ Ask a question: ${config.PREFIX}8ball will I pass my exam?`);
            await say(sock, from, msg, `🎱 *${args.join(" ")}*\n\n${pick(BALL)}`);
        }
    },
    {
        name: "flip", aliases: ["coin", "coinflip"],
        async execute(sock, from, args, msg) { await say(sock, from, msg, Math.random() < 0.5 ? "🪙 *HEADS*" : "🪙 *TAILS*"); }
    },
    {
        name: "dice", aliases: ["roll"],
        async execute(sock, from, args, msg) {
            const sides = Math.min(Math.max(parseInt(args[0], 10) || 6, 2), 1000);
            await say(sock, from, msg, `🎲 You rolled *${1 + crypto.randomInt(sides)}* (d${sides})`);
        }
    },
    {
        name: "rps",
        async execute(sock, from, args, msg) {
            const moves = ["rock", "paper", "scissors"];
            const user = (args[0] || "").toLowerCase();
            if (!moves.includes(user)) return say(sock, from, msg, `❌ ${config.PREFIX}rps rock | paper | scissors`);
            const bot = pick(moves);
            const win = (user === "rock" && bot === "scissors") || (user === "paper" && bot === "rock") || (user === "scissors" && bot === "paper");
            await say(sock, from, msg, `✊ You: *${user}*\n🤖 Bot: *${bot}*\n\n${user === bot ? "🤝 Draw!" : win ? "🎉 You win!" : "🤖 I win!"}`);
        }
    },
    { name: "truth", async execute(sock, from, args, msg) { await say(sock, from, msg, "🫣 *TRUTH*\n" + pick(TRUTHS)); } },
    { name: "dare", async execute(sock, from, args, msg) { await say(sock, from, msg, "😈 *DARE*\n" + pick(DARES)); } },
    { name: "pickup", aliases: ["pickupline"], async execute(sock, from, args, msg) { await say(sock, from, msg, "💘 " + pick(PICKUPS)); } },
    {
        name: "compliment",
        async execute(sock, from, args, msg) {
            const t = targetOf(msg);
            await say(sock, from, msg, (t ? `@${jidNum(t)} ` : "") + pick(COMPLIMENTS), t ? { mentions: [t] } : {});
        }
    },
    {
        name: "roast",
        async execute(sock, from, args, msg) {
            const t = targetOf(msg);
            await say(sock, from, msg, "🔥 " + (t ? `@${jidNum(t)} ` : "") + pick(ROASTS) + "\n\n_(just for laughs)_", t ? { mentions: [t] } : {});
        }
    },
    {
        name: "ship",
        async execute(sock, from, args, msg) {
            const t = targetOf(msg);
            let a, b, mentions = [];
            if (t) { a = "@" + jidNum(msg.key.participant || msg.key.remoteJid); b = "@" + jidNum(t); mentions = [msg.key.participant || msg.key.remoteJid, t]; }
            else {
                const parts = args.join(" ").split(/\s*(?:\||&|and)\s*/i).filter(Boolean);
                if (parts.length < 2) return say(sock, from, msg, `❌ ${config.PREFIX}ship Amina | Brian\n(or reply to someone / mention them)`);
                [a, b] = parts;
            }
            const pct = parseInt(crypto.createHash("md5").update([a, b].map(s => s.toLowerCase()).sort().join("+")).digest("hex").slice(0, 4), 16) % 101;
            const bar = "❤️".repeat(Math.round(pct / 10)) + "🖤".repeat(10 - Math.round(pct / 10));
            await say(sock, from, msg, `💞 *LOVE METER*\n\n${a} + ${b}\n${bar}\n*${pct}%*`, mentions.length ? { mentions } : {});
        }
    },
    {
        name: "rate",
        async execute(sock, from, args, msg) {
            const what = args.join(" ");
            if (!what) return say(sock, from, msg, `❌ ${config.PREFIX}rate my cooking`);
            const pct = parseInt(crypto.createHash("md5").update(what.toLowerCase()).digest("hex").slice(0, 4), 16) % 101;
            await say(sock, from, msg, `⭐ *${what}*\nI rate it *${pct}/100*`);
        }
    },
    {
        name: "choose", aliases: ["pick"],
        async execute(sock, from, args, msg) {
            const opts = args.join(" ").split("|").map(s => s.trim()).filter(Boolean);
            if (opts.length < 2) return say(sock, from, msg, `❌ ${config.PREFIX}choose pizza | burger | rice`);
            await say(sock, from, msg, `🤔 I choose: *${pick(opts)}*`);
        }
    },
    {
        name: "slot", aliases: ["slots"],
        async execute(sock, from, args, msg) {
            const s = ["🍒", "🍋", "🔔", "💎", "7️⃣", "🍇"];
            const r = [pick(s), pick(s), pick(s)];
            const result = r[0] === r[1] && r[1] === r[2] ? "🎉 *JACKPOT!*" : (r[0] === r[1] || r[1] === r[2] || r[0] === r[2]) ? "👍 Two match, nice!" : "😢 Try again";
            await say(sock, from, msg, `🎰 *SLOTS*\n\n[ ${r.join(" | ")} ]\n\n${result}`);
        }
    },
    {
        name: "riddle",
        async execute(sock, from, args, msg) {
            const [q, a] = pick(RIDDLES);
            await say(sock, from, msg, `🧩 *RIDDLE*\n${q}\n\n_Answer in 20 seconds..._`);
            await sleep(20000);
            await say(sock, from, msg, `💡 Answer: *${a}*`);
        }
    },
    {
        name: "trivia", aliases: ["quiz"],
        async execute(sock, from, args, msg) {
            try {
                const d = (await getJson("https://opentdb.com/api.php?amount=1&type=multiple")).results[0];
                const answer = decodeHtml(d.correct_answer);
                const options = [...d.incorrect_answers.map(decodeHtml), answer].sort(() => Math.random() - 0.5);
                const letters = ["A", "B", "C", "D"];
                await say(sock, from, msg, `🧠 *TRIVIA* (${decodeHtml(d.category)} • ${d.difficulty})\n\n${decodeHtml(d.question)}\n\n${options.map((o, i) => `${letters[i]}. ${o}`).join("\n")}\n\n_Answer in 25 seconds..._`);
                await sleep(25000);
                await say(sock, from, msg, `✅ Correct answer: *${letters[options.indexOf(answer)]}. ${answer}*`);
            } catch (e) { await say(sock, from, msg, "❌ Could not load a trivia question. Try again in a moment."); }
        }
    }
];
