const config = require("../config/config");
const settingsStore = require("../utils/settingsStore");
const groupSettings = require("../utils/groupSettingsStore");
const { isDev, isOwner, isAdmin, isBotAdmin } = require("../utils/auth");
const { getMediaTarget, download } = require("../utils/media");
const { box, jidNum } = require("../utils/helpers");

const say = (sock, from, msg, text, extra = {}) => sock.sendMessage(from, { text, ...extra }, { quoted: msg });
const who = (msg, extra) => extra.sender || msg.key.participant || msg.key.remoteJid;

function extractTarget(args, msg) {
    const ctx = msg.message?.extendedTextMessage?.contextInfo;
    const digits = args[0]?.replace(/\D/g, "");
    return ctx?.mentionedJid?.[0] || ctx?.participant || (digits && digits.length >= 8 ? digits + "@s.whatsapp.net" : null);
}

// Turns a setting on or off. "on" / "off" sets it, anything else flips it.
function nextValue(arg, current) {
    const a = (arg || "").toLowerCase();
    if (a === "on") return true;
    if (a === "off") return false;
    return !current;
}

// A per-number switch such as .autoread (owner only)
function ownerSwitch(name, icon, label, note) {
    return {
        name,
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            const key = `${extra.sessionOwner}_${name}`;
            const value = nextValue(args[0], settingsStore.get(key, false));
            settingsStore.set(key, value);
            await say(sock, from, msg, `${icon} ${label}: *${value ? "ON" : "OFF"}*${note ? `\n_${note}_` : ""}`);
        }
    };
}

// A per-group protection switch such as .antilink (group admins and owner)
function groupSwitch(name, label) {
    return {
        name,
        async execute(sock, from, args, msg, extra = {}) {
            if (!from.endsWith("@g.us")) return say(sock, from, msg, "❌ Group only.");
            const sender = who(msg, extra);
            if (!isOwner(sender, extra) && !(await isAdmin(sock, from, sender))) return say(sock, from, msg, "❌ Admin/Owner only.");
            const value = nextValue(args[0], groupSettings.get(from, name, true));
            groupSettings.set(from, name, value);
            await say(sock, from, msg, `🛡️ ${label}: *${value ? "ON" : "OFF"}*`);
        }
    };
}

// promote / demote / kick
function memberAction(name, action, doneText) {
    return {
        name,
        async execute(sock, from, args, msg, extra = {}) {
            if (!from.endsWith("@g.us")) return say(sock, from, msg, "❌ Group only.");
            const sender = who(msg, extra);
            if (!isOwner(sender, extra) && !(await isAdmin(sock, from, sender))) return say(sock, from, msg, "❌ Admin only.");
            if (!(await isBotAdmin(sock, from))) return say(sock, from, msg, "❌ Make me a group admin first, then try again.");
            const t = extractTarget(args, msg);
            if (!t) return say(sock, from, msg, `❌ Mention or reply to a user: ${config.PREFIX}${name} @user`);
            try {
                await sock.groupParticipantsUpdate(from, [t], action);
                await say(sock, from, msg, `✅ ${doneText} @${jidNum(t)}`, { mentions: [t] });
            } catch (e) { await say(sock, from, msg, "❌ WhatsApp refused that action."); }
        }
    };
}

module.exports = [
    // ───── bot settings (owner only) ─────
    {
        name: "mode",
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            const key = `${extra.sessionOwner}_mode`;
            const current = settingsStore.get(key, "public");
            const wanted = (args[0] || "").toLowerCase();
            if (!["public", "private"].includes(wanted)) {
                return say(sock, from, msg, box("BOT MODE", [
                    `🛡️ *Now:* ${current.toUpperCase()}`,
                    "🌍 *public* – everyone can use the bot",
                    "🔒 *private* – only the owner can use it; everyone else is ignored",
                    `✏️ ${config.PREFIX}mode public  or  ${config.PREFIX}mode private`
                ]));
            }
            settingsStore.set(key, wanted);
            await say(sock, from, msg, wanted === "public" ? "🌍 Mode: *PUBLIC*. Everyone can use the bot." : "🔒 Mode: *PRIVATE*. Only you can use the bot now.");
        }
    },
    {
        name: "settings",
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            const on = (k) => (settingsStore.get(`${extra.sessionOwner}_${k}`, false) ? "ON ✅" : "OFF ❌");
            await say(sock, from, msg, box("BOT SETTINGS", [
                `🛡️ *Mode:* ${settingsStore.get(`${extra.sessionOwner}_mode`, "public").toUpperCase()}`,
                `🔑 *Prefix:* ${config.PREFIX}`,
                `👀 *Auto-read:* ${on("autoread")}`,
                `🟢 *Always online:* ${on("alwaysonline")}`,
                `📝 *Auto-bio:* ${on("autobio")}`
            ]));
        }
    },
    {
        name: "setprefix",
        async execute(sock, from, args, msg, extra = {}) {
            // Prefix is stored per paired session; only that session owner/developer may change it.
            const sender = who(msg, extra);
            if (!isOwner(sender, extra)) return say(sock, from, msg, "❌ Only the paired account owner can change this session's prefix.");
            if (!args[0] || args[0].length > 3) return say(sock, from, msg, "❌ Usage: .setprefix <1-3 symbols>   e.g. .setprefix !");
            const key = `${extra.sessionOwner}_prefix`;
            settingsStore.set(key, args[0]);
            await say(sock, from, msg, `✅ Prefix changed for this session to: *${args[0]}*\n_It persists across restarts._`);
        }
    },
    ownerSwitch("autoread", "👀", "Auto-read", "Marks incoming messages as read."),
    ownerSwitch("alwaysonline", "🟢", "Always online", "Keeps your number showing as online."),
    ownerSwitch("autobio", "📝", "Auto-bio", "Changes your About text every hour."),
    {
        name: "broadcast", aliases: ["bc"],
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            const text = args.join(" ");
            if (!text) return say(sock, from, msg, `❌ ${config.PREFIX}broadcast <message>`);
            try {
                const ids = Object.keys(await sock.groupFetchAllParticipating());
                await say(sock, from, msg, `📣 Sending to ${ids.length} groups...`);
                let sent = 0;
                for (const id of ids) {
                    try { await sock.sendMessage(id, { text: `📢 *BROADCAST*\n\n${text}` }); sent++; } catch (e) {}
                    await new Promise(r => setTimeout(r, 2500)); // slow on purpose, fast sending can get a number banned
                }
                await say(sock, from, msg, `✅ Broadcast sent to ${sent} of ${ids.length} groups.`);
            } catch (e) { await say(sock, from, msg, "❌ Broadcast failed."); }
        }
    },
    {
        name: "block",
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            const t = extractTarget(args, msg) || (from.endsWith("@g.us") ? null : from);
            if (!t) return say(sock, from, msg, `❌ Reply to someone or give a number: ${config.PREFIX}block 2547XXXXXXXX`);
            try { await sock.updateBlockStatus(t, "block"); await say(sock, from, msg, `🚫 Blocked @${jidNum(t)}`, { mentions: [t] }); }
            catch (e) { await say(sock, from, msg, "❌ Could not block that number."); }
        }
    },
    {
        name: "unblock",
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            const t = extractTarget(args, msg) || (from.endsWith("@g.us") ? null : from);
            if (!t) return say(sock, from, msg, `❌ Reply to someone or give a number: ${config.PREFIX}unblock 2547XXXXXXXX`);
            try { await sock.updateBlockStatus(t, "unblock"); await say(sock, from, msg, `✅ Unblocked @${jidNum(t)}`, { mentions: [t] }); }
            catch (e) { await say(sock, from, msg, "❌ Could not unblock that number."); }
        }
    },
    {
        name: "setbio", aliases: ["setstatus"],
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            if (!args.length) return say(sock, from, msg, `❌ ${config.PREFIX}setbio <new About text>`);
            try { await sock.updateProfileStatus(args.join(" ").slice(0, 139)); await say(sock, from, msg, "✅ Your About text was updated."); }
            catch (e) { await say(sock, from, msg, "❌ Could not update the About text."); }
        }
    },
    {
        name: "setpp", aliases: ["setdp"],
        async execute(sock, from, args, msg, extra = {}) {
            if (!isOwner(who(msg, extra), extra)) return say(sock, from, msg, "❌ Owner only.");
            const t = getMediaTarget(msg);
            if (!t || t.kind !== "image") return say(sock, from, msg, `❌ Reply to a photo with ${config.PREFIX}setpp`);
            try {
                const buf = await download(sock, t);
                await sock.updateProfilePicture(sock.user.id, buf);
                await say(sock, from, msg, "✅ Profile picture updated.");
            } catch (e) { await say(sock, from, msg, "❌ Could not update the profile picture."); }
        }
    },
    {
        name: "getpp", aliases: ["pp", "profilepic"],
        async execute(sock, from, args, msg, extra = {}) {
            const t = extractTarget(args, msg) || who(msg, extra);
            try {
                const url = await sock.profilePictureUrl(t, "image");
                await sock.sendMessage(from, { image: { url }, caption: `🖼️ Profile picture of @${jidNum(t)}`, mentions: [t] }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ No profile picture found (it may be private or not set)."); }
        }
    },

    // ───── group protection ─────
    groupSwitch("antilink", "Antilink"),
    groupSwitch("antispam", "Antispam"),

    // ───── group members ─────
    memberAction("promote", "promote", "Promoted"),
    memberAction("demote", "demote", "Demoted"),
    memberAction("kick", "remove", "Removed")
];
