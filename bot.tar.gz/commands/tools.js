const crypto = require("crypto");
const config = require("../config/config");
const { getJson, getBuffer, getText } = require("../utils/net");
const { box, clip, pick } = require("../utils/helpers");

const say = (sock, from, msg, text, extra = {}) => sock.sendMessage(from, { text, ...extra }, { quoted: msg });
const needs = (sock, from, msg, usage) => say(sock, from, msg, `❌ Usage: ${config.PREFIX}${usage}`);
const num = (n) => Number(n).toLocaleString("en-US", { maximumFractionDigits: 2 });

// ── fancy letters ──
function mapRange(text, upper, lower, digit, special = {}) {
    return [...text].map(ch => {
        if (special[ch]) return special[ch];
        const c = ch.codePointAt(0);
        if (c >= 65 && c <= 90) return String.fromCodePoint(upper + c - 65);
        if (c >= 97 && c <= 122) return String.fromCodePoint(lower + c - 97);
        if (digit && c >= 48 && c <= 57) return String.fromCodePoint(digit + c - 48);
        return ch;
    }).join("");
}
function bubble(text) {
    return [...text].map(ch => {
        const c = ch.codePointAt(0);
        if (c >= 65 && c <= 90) return String.fromCodePoint(0x24B6 + c - 65);
        if (c >= 97 && c <= 122) return String.fromCodePoint(0x24D0 + c - 97);
        if (c >= 49 && c <= 57) return String.fromCodePoint(0x2460 + c - 49);
        if (c === 48) return "⓪";
        return ch;
    }).join("");
}
const STYLES = {
    bold: t => mapRange(t, 0x1D5D4, 0x1D5EE, 0x1D7EC),
    italic: t => mapRange(t, 0x1D434, 0x1D44E, 0, { h: "ℎ" }),
    script: t => mapRange(t, 0x1D4D0, 0x1D4EA, 0),
    mono: t => mapRange(t, 0x1D670, 0x1D68A, 0x1D7F6),
    serif: t => mapRange(t, 0x1D400, 0x1D41A, 0x1D7CE),
    bubble
};

const UPSIDE = { a: "ɐ", b: "q", c: "ɔ", d: "p", e: "ǝ", f: "ɟ", g: "ƃ", h: "ɥ", i: "ᴉ", j: "ɾ", k: "ʞ", l: "l", m: "ɯ", n: "u", o: "o", p: "d", q: "b", r: "ɹ", s: "s", t: "ʇ", u: "n", v: "ʌ", w: "ʍ", x: "x", y: "ʎ", z: "z", "?": "¿", "!": "¡", ".": "˙", ",": "'", "'": ",", "(": ")", ")": "(" };
const MORSE = { A: ".-", B: "-...", C: "-.-.", D: "-..", E: ".", F: "..-.", G: "--.", H: "....", I: "..", J: ".---", K: "-.-", L: ".-..", M: "--", N: "-.", O: "---", P: ".--.", Q: "--.-", R: ".-.", S: "...", T: "-", U: "..-", V: "...-", W: ".--", X: "-..-", Y: "-.--", Z: "--..", 0: "-----", 1: ".----", 2: "..---", 3: "...--", 4: "....-", 5: ".....", 6: "-....", 7: "--...", 8: "---..", 9: "----." };

const WEATHER = { 0: "Clear sky ☀️", 1: "Mainly clear 🌤️", 2: "Partly cloudy ⛅", 3: "Overcast ☁️", 45: "Fog 🌫️", 48: "Fog 🌫️", 51: "Light drizzle 🌦️", 53: "Drizzle 🌦️", 55: "Heavy drizzle 🌧️", 56: "Freezing drizzle 🌧️", 57: "Freezing drizzle 🌧️", 61: "Light rain 🌦️", 63: "Rain 🌧️", 65: "Heavy rain 🌧️", 66: "Freezing rain 🌧️", 67: "Freezing rain 🌧️", 71: "Light snow 🌨️", 73: "Snow 🌨️", 75: "Heavy snow ❄️", 77: "Snow grains ❄️", 80: "Rain showers 🌦️", 81: "Rain showers 🌧️", 82: "Violent showers ⛈️", 85: "Snow showers 🌨️", 86: "Snow showers 🌨️", 95: "Thunderstorm ⛈️", 96: "Thunderstorm with hail ⛈️", 99: "Thunderstorm with hail ⛈️" };

const COINS = { btc: "bitcoin", eth: "ethereum", usdt: "tether", bnb: "binancecoin", sol: "solana", xrp: "ripple", ada: "cardano", doge: "dogecoin", trx: "tron", ton: "the-open-network", ltc: "litecoin", dot: "polkadot", matic: "matic-network", shib: "shiba-inu", avax: "avalanche-2" };

function textOf(args, msg) {
    if (args.length) return args.join(" ");
    const q = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    return q?.conversation || q?.extendedTextMessage?.text || "";
}

module.exports = [
    // ───────────── information ─────────────
    {
        name: "weather", aliases: ["wx"],
        async execute(sock, from, args, msg) {
            const city = args.join(" ");
            if (!city) return needs(sock, from, msg, "weather <city>   e.g. weather Nairobi");
            try {
                const geo = await getJson("https://geocoding-api.open-meteo.com/v1/search", { params: { name: city, count: 1 } });
                const p = geo.results?.[0];
                if (!p) return say(sock, from, msg, `❌ I couldn't find a place called *${city}*.`);
                const w = await getJson("https://api.open-meteo.com/v1/forecast", { params: {
                    latitude: p.latitude, longitude: p.longitude, timezone: "auto",
                    current: "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code",
                    daily: "temperature_2m_max,temperature_2m_min,precipitation_probability_max", forecast_days: 1
                } });
                const c = w.current, d = w.daily;
                await say(sock, from, msg, box(`WEATHER • ${p.name}`, [
                    `🌍 ${[p.name, p.admin1, p.country].filter(Boolean).join(", ")}`,
                    `🌡️ *Now:* ${c.temperature_2m}°C (feels ${c.apparent_temperature}°C)`,
                    `☁️ *Sky:* ${WEATHER[c.weather_code] || "Unknown"}`,
                    `💧 *Humidity:* ${c.relative_humidity_2m}%`,
                    `💨 *Wind:* ${c.wind_speed_10m} km/h`,
                    `📈 *Today:* ${d.temperature_2m_min[0]}° to ${d.temperature_2m_max[0]}°C`,
                    `☔ *Rain chance:* ${d.precipitation_probability_max[0] ?? 0}%`
                ]));
            } catch (e) { await say(sock, from, msg, "❌ Weather service is unavailable right now. Try again shortly."); }
        }
    },
    {
        name: "define", aliases: ["dictionary", "meaning"],
        async execute(sock, from, args, msg) {
            const word = args[0];
            if (!word) return needs(sock, from, msg, "define <word>");
            try {
                const d = (await getJson(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`))[0];
                const lines = d.meanings.slice(0, 3).map(m => `📖 _${m.partOfSpeech}_\n${m.definitions[0].definition}${m.definitions[0].example ? `\n💬 "${m.definitions[0].example}"` : ""}`);
                await say(sock, from, msg, `*${d.word}* ${d.phonetic || ""}\n\n${lines.join("\n\n")}`);
            } catch (e) { await say(sock, from, msg, `❌ No definition found for *${word}*.`); }
        }
    },
    {
        name: "wiki", aliases: ["wikipedia"],
        async execute(sock, from, args, msg) {
            const q = args.join(" ");
            if (!q) return needs(sock, from, msg, "wiki <topic>");
            try {
                const found = await getJson("https://en.wikipedia.org/w/api.php", { params: { action: "opensearch", search: q, limit: 1, format: "json" } });
                const title = found[1]?.[0];
                if (!title) return say(sock, from, msg, `❌ Nothing found for *${q}*.`);
                const s = await getJson(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`);
                await say(sock, from, msg, `📚 *${s.title}*\n\n${clip(s.extract, 1500)}\n\n🔗 ${s.content_urls?.desktop?.page || ""}`);
            } catch (e) { await say(sock, from, msg, "❌ Wikipedia is unavailable right now."); }
        }
    },
    {
        name: "translate", aliases: ["tr", "trt"],
        async execute(sock, from, args, msg) {
            const lang = (args[0] || "").toLowerCase();
            const quoted = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const text = args.slice(1).join(" ") || quoted?.conversation || quoted?.extendedTextMessage?.text || "";
            if (!/^[a-z]{2}(-[a-z]{2})?$/.test(lang) || !text) return needs(sock, from, msg, "translate <language code> <text>   e.g. translate sw good morning\n(or reply to a message: translate fr)");
            try {
                const r = await getJson("https://api.mymemory.translated.net/get", { params: { q: text.slice(0, 450), langpair: `Autodetect|${lang}` } });
                const out = r.responseData?.translatedText;
                if (!out) throw new Error("none");
                await say(sock, from, msg, `🌍 *Translation (${lang})*\n\n${out}`);
            } catch (e) { await say(sock, from, msg, "❌ Translation failed. Check the language code (en, sw, fr, es, ar...) and try again."); }
        }
    },
    {
        name: "currency", aliases: ["convert", "fx"],
        async execute(sock, from, args, msg) {
            const amount = parseFloat(args[0]);
            const a = (args[1] || "").toUpperCase(), b = (args[2] || "").toUpperCase();
            if (!amount || !a || !b) return needs(sock, from, msg, "currency 100 usd kes");
            try {
                const rates = (await getJson("https://open.er-api.com/v6/latest/USD")).rates;
                if (!rates[a] || !rates[b]) return say(sock, from, msg, "❌ Unknown currency code.");
                const out = amount / rates[a] * rates[b];
                await say(sock, from, msg, `💱 *${num(amount)} ${a}* = *${num(out)} ${b}*\n_Rate: 1 ${a} = ${num(rates[b] / rates[a])} ${b}_`);
            } catch (e) { await say(sock, from, msg, "❌ Exchange rates are unavailable right now."); }
        }
    },
    {
        name: "crypto", aliases: ["coin"],
        async execute(sock, from, args, msg) {
            const sym = (args[0] || "").toLowerCase();
            if (!sym) return needs(sock, from, msg, "crypto btc   (btc, eth, sol, bnb, xrp, doge, ton...)");
            const id = COINS[sym] || sym;
            try {
                const r = await getJson("https://api.coingecko.com/api/v3/simple/price", { params: { ids: id, vs_currencies: "usd,kes", include_24hr_change: true } });
                const d = r[id];
                if (!d) return say(sock, from, msg, "❌ Coin not found. Try btc, eth, sol, bnb, xrp, doge, ton.");
                const ch = d.usd_24h_change;
                await say(sock, from, msg, box(`CRYPTO • ${sym.toUpperCase()}`, [`💵 *USD:* $${num(d.usd)}`, `🇰🇪 *KES:* ${num(d.kes)}`, `${ch >= 0 ? "📈" : "📉"} *24h:* ${ch >= 0 ? "+" : ""}${ch.toFixed(2)}%`]));
            } catch (e) { await say(sock, from, msg, "❌ Price service is busy. Try again in a minute."); }
        }
    },
    {
        name: "country",
        async execute(sock, from, args, msg) {
            const q = args.join(" ");
            if (!q) return needs(sock, from, msg, "country Kenya");
            try {
                const c = (await getJson(`https://restcountries.com/v3.1/name/${encodeURIComponent(q)}`))[0];
                const text = box(`${c.name.common.toUpperCase()} ${c.flag || ""}`, [
                    `🏛️ *Capital:* ${(c.capital || []).join(", ") || "-"}`, `🌍 *Region:* ${c.region}${c.subregion ? ` (${c.subregion})` : ""}`,
                    `👥 *Population:* ${num(c.population)}`, `💰 *Currency:* ${Object.values(c.currencies || {}).map(x => `${x.name} (${x.symbol || ""})`).join(", ") || "-"}`,
                    `🗣️ *Languages:* ${Object.values(c.languages || {}).join(", ") || "-"}`, `📐 *Area:* ${num(c.area)} km²`
                ]);
                if (c.flags?.png) { try { return await sock.sendMessage(from, { image: { url: c.flags.png }, caption: text }, { quoted: msg }); } catch (e) {} }
                await say(sock, from, msg, text);
            } catch (e) { await say(sock, from, msg, `❌ No country found for *${q}*.`); }
        }
    },
    {
        name: "pokemon",
        async execute(sock, from, args, msg) {
            const q = (args[0] || "").toLowerCase();
            if (!q) return needs(sock, from, msg, "pokemon pikachu");
            try {
                const p = await getJson(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(q)}`);
                const text = box(`${p.name.toUpperCase()} #${p.id}`, [
                    `🔥 *Type:* ${p.types.map(t => t.type.name).join(", ")}`, `📏 *Height:* ${p.height / 10} m`, `⚖️ *Weight:* ${p.weight / 10} kg`,
                    `✨ *Abilities:* ${p.abilities.map(a => a.ability.name).join(", ")}`, `❤️ *HP:* ${p.stats[0].base_stat}  ⚔️ *ATK:* ${p.stats[1].base_stat}  🛡️ *DEF:* ${p.stats[2].base_stat}`
                ]);
                const img = p.sprites?.other?.["official-artwork"]?.front_default || p.sprites?.front_default;
                if (img) { try { return await sock.sendMessage(from, { image: { url: img }, caption: text }, { quoted: msg }); } catch (e) {} }
                await say(sock, from, msg, text);
            } catch (e) { await say(sock, from, msg, `❌ No Pokémon found called *${q}*.`); }
        }
    },
    {
        name: "recipe", aliases: ["meal"],
        async execute(sock, from, args, msg) {
            const q = args.join(" ");
            if (!q) return needs(sock, from, msg, "recipe chicken");
            try {
                const m = (await getJson("https://www.themealdb.com/api/json/v1/1/search.php", { params: { s: q } })).meals?.[0];
                if (!m) return say(sock, from, msg, `❌ No recipe found for *${q}*.`);
                const ing = [];
                for (let i = 1; i <= 20; i++) if (m[`strIngredient${i}`]) ing.push(`• ${m[`strMeasure${i}`] || ""} ${m[`strIngredient${i}`]}`.trim());
                const text = `🍽️ *${m.strMeal}*  (${m.strCategory}, ${m.strArea})\n\n*Ingredients*\n${ing.join("\n")}\n\n*Method*\n${clip(m.strInstructions, 1800)}`;
                if (m.strMealThumb) { try { return await sock.sendMessage(from, { image: { url: m.strMealThumb }, caption: text }, { quoted: msg }); } catch (e) {} }
                await say(sock, from, msg, text);
            } catch (e) { await say(sock, from, msg, "❌ Recipe service is unavailable right now."); }
        }
    },
    {
        name: "lyrics",
        async execute(sock, from, args, msg) {
            const parts = args.join(" ").split(/\s+-\s+/);
            if (parts.length < 2) return needs(sock, from, msg, "lyrics artist - song   e.g. lyrics Sauti Sol - Melanin");
            try {
                const d = await getJson(`https://api.lyrics.ovh/v1/${encodeURIComponent(parts[0])}/${encodeURIComponent(parts[1])}`);
                if (!d.lyrics) throw new Error("none");
                await say(sock, from, msg, `🎵 *${parts[1]}* — ${parts[0]}\n\n${clip(d.lyrics, 3500)}`);
            } catch (e) { await say(sock, from, msg, "❌ Lyrics not found. Use the format: artist - song"); }
        }
    },
    {
        name: "github", aliases: ["gh"],
        async execute(sock, from, args, msg) {
            const u = args[0];
            if (!u) return needs(sock, from, msg, "github <username>");
            try {
                const d = await getJson(`https://api.github.com/users/${encodeURIComponent(u)}`);
                const text = box(`GITHUB • ${d.login}`, [`👤 ${d.name || d.login}`, `📝 ${d.bio || "No bio"}`, `📦 *Repos:* ${d.public_repos}`, `👥 *Followers:* ${d.followers}  *Following:* ${d.following}`, `📍 ${d.location || "-"}`, `🔗 ${d.html_url}`]);
                try { return await sock.sendMessage(from, { image: { url: d.avatar_url }, caption: text }, { quoted: msg }); } catch (e) {}
                await say(sock, from, msg, text);
            } catch (e) { await say(sock, from, msg, `❌ GitHub user *${u}* not found.`); }
        }
    },
    {
        name: "npm",
        async execute(sock, from, args, msg) {
            const p = args[0];
            if (!p) return needs(sock, from, msg, "npm <package>");
            try {
                const d = await getJson(`https://registry.npmjs.org/${encodeURIComponent(p)}/latest`);
                await say(sock, from, msg, box(`NPM • ${d.name}`, [`🏷️ *Version:* ${d.version}`, `📝 ${d.description || "-"}`, `⚖️ *License:* ${d.license || "-"}`, `🔗 https://www.npmjs.com/package/${d.name}`]));
            } catch (e) { await say(sock, from, msg, `❌ npm package *${p}* not found.`); }
        }
    },
    {
        name: "ip", aliases: ["iplookup"],
        async execute(sock, from, args, msg) {
            const ip = args[0];
            if (!ip) return needs(sock, from, msg, "ip 8.8.8.8");
            try {
                const d = await getJson(`http://ip-api.com/json/${encodeURIComponent(ip)}`, { params: { fields: "status,message,country,regionName,city,isp,lat,lon,timezone,query" } });
                if (d.status !== "success") return say(sock, from, msg, `❌ ${d.message || "Lookup failed"}`);
                await say(sock, from, msg, box(`IP • ${d.query}`, [`🌍 ${d.city}, ${d.regionName}, ${d.country}`, `🏢 *ISP:* ${d.isp}`, `🕐 *Timezone:* ${d.timezone}`, `📍 ${d.lat}, ${d.lon}`]));
            } catch (e) { await say(sock, from, msg, "❌ IP lookup is unavailable right now."); }
        }
    },

    // ───────────── generators ─────────────
    {
        name: "qr", aliases: ["qrcode"],
        async execute(sock, from, args, msg) {
            const t = textOf(args, msg);
            if (!t) return needs(sock, from, msg, "qr <text or link>");
            try {
                const buf = await getBuffer(`https://api.qrserver.com/v1/create-qr-code/?size=600x600&margin=10&data=${encodeURIComponent(t)}`);
                await sock.sendMessage(from, { image: buf, caption: "✅ Your QR code" }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not create the QR code right now."); }
        }
    },
    {
        name: "shorten", aliases: ["short", "tinyurl"],
        async execute(sock, from, args, msg) {
            const url = args[0];
            if (!/^https?:\/\//i.test(url || "")) return needs(sock, from, msg, "shorten https://example.com/very/long/link");
            try {
                const out = (await getText("https://tinyurl.com/api-create.php?url=" + encodeURIComponent(url))).trim();
                if (!/^https?:\/\//.test(out)) throw new Error(out);
                await say(sock, from, msg, `🔗 *Short link:*\n${out}`);
            } catch (e) { await say(sock, from, msg, "❌ Could not shorten that link."); }
        }
    },
    {
        name: "ssweb", aliases: ["screenshot", "ss"],
        async execute(sock, from, args, msg) {
            let url = args[0];
            if (!url) return needs(sock, from, msg, "ssweb https://example.com");
            if (!/^https?:\/\//i.test(url)) url = "https://" + url;
            try {
                const buf = await getBuffer(`https://image.thum.io/get/width/1280/crop/800/noanimate/${url}`, { timeout: 60000 });
                if (buf.length < 3000) throw new Error("empty");
                await sock.sendMessage(from, { image: buf, caption: `🖥️ ${url}` }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not take a screenshot of that page."); }
        }
    },
    {
        name: "tts", aliases: ["say2", "speak"],
        async execute(sock, from, args, msg) {
            let lang = "en";
            const a = [...args];
            if (a.length > 1 && /^[a-z]{2}$/i.test(a[0])) lang = a.shift().toLowerCase();
            const text = a.join(" ") || textOf([], msg);
            if (!text) return needs(sock, from, msg, "tts <text>   or   tts sw habari za asubuhi");
            try {
                const buf = await getBuffer(`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(text.slice(0, 190))}`);
                if (buf.length < 500) throw new Error("empty");
                await sock.sendMessage(from, { audio: buf, mimetype: "audio/mpeg", ptt: false }, { quoted: msg });
            } catch (e) { await say(sock, from, msg, "❌ Could not create the voice message right now."); }
        }
    },
    {
        name: "password", aliases: ["pass", "genpass"],
        async execute(sock, from, args, msg) {
            const len = Math.min(Math.max(parseInt(args[0], 10) || 16, 8), 64);
            const set = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*?";
            let out = "";
            for (let i = 0; i < len; i++) out += set[crypto.randomInt(set.length)];
            await say(sock, from, msg, `🔐 *Password (${len})*\n\`\`\`${out}\`\`\`\n_Save it somewhere safe. I don't store it._`);
        }
    },
    { name: "uuid", async execute(sock, from, args, msg) { await say(sock, from, msg, "🆔 ```" + crypto.randomUUID() + "```"); } },
    {
        name: "random", aliases: ["rand"],
        async execute(sock, from, args, msg) {
            let a = parseInt(args[0], 10), b = parseInt(args[1], 10);
            if (isNaN(a)) { a = 1; b = 100; } else if (isNaN(b)) { b = a; a = 1; }
            if (a > b) [a, b] = [b, a];
            await say(sock, from, msg, `🎯 Random number between ${a} and ${b}: *${a + crypto.randomInt(b - a + 1)}*`);
        }
    },

    // ───────────── text tools ─────────────
    {
        name: "hash",
        async execute(sock, from, args, msg) {
            const algo = (args[0] || "").toLowerCase();
            const text = args.slice(1).join(" ");
            if (!["md5", "sha1", "sha256", "sha512"].includes(algo) || !text) return needs(sock, from, msg, "hash <md5|sha1|sha256|sha512> <text>");
            await say(sock, from, msg, `#️⃣ *${algo.toUpperCase()}*\n\`\`\`${crypto.createHash(algo).update(text).digest("hex")}\`\`\``);
        }
    },
    { name: "base64", aliases: ["b64"], async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "base64 <text>"); await say(sock, from, msg, Buffer.from(t).toString("base64")); } },
    {
        name: "unbase64", aliases: ["b64d"],
        async execute(sock, from, args, msg) {
            const t = textOf(args, msg);
            if (!t) return needs(sock, from, msg, "unbase64 <text>");
            try { await say(sock, from, msg, Buffer.from(t.trim(), "base64").toString("utf8")); } catch (e) { await say(sock, from, msg, "❌ That is not valid base64."); }
        }
    },
    { name: "binary", async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "binary <text>"); await say(sock, from, msg, [...t].map(c => c.charCodeAt(0).toString(2).padStart(8, "0")).join(" ")); } },
    {
        name: "unbinary",
        async execute(sock, from, args, msg) {
            const t = textOf(args, msg);
            if (!/^[01\s]+$/.test(t || "")) return needs(sock, from, msg, "unbinary 01001000 01101001");
            await say(sock, from, msg, t.trim().split(/\s+/).map(b => String.fromCharCode(parseInt(b, 2))).join(""));
        }
    },
    { name: "morse", async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "morse <text>"); await say(sock, from, msg, t.toUpperCase().split("").map(c => MORSE[c] || (c === " " ? "/" : c)).join(" ")); } },
    { name: "reverse", async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "reverse <text>"); await say(sock, from, msg, [...t].reverse().join("")); } },
    { name: "fliptext", aliases: ["upsidedown"], async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "fliptext <text>"); await say(sock, from, msg, [...t.toLowerCase()].reverse().map(c => UPSIDE[c] || c).join("")); } },
    { name: "uppercase", aliases: ["upper"], async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "uppercase <text>"); await say(sock, from, msg, t.toUpperCase()); } },
    { name: "lowercase", aliases: ["lower"], async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "lowercase <text>"); await say(sock, from, msg, t.toLowerCase()); } },
    { name: "titlecase", aliases: ["title"], async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "titlecase <text>"); await say(sock, from, msg, t.toLowerCase().replace(/\b\w/g, c => c.toUpperCase())); } },
    { name: "mock", aliases: ["spongebob"], async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "mock <text>"); let i = 0; await say(sock, from, msg, [...t.toLowerCase()].map(c => (/[a-z]/.test(c) ? (i++ % 2 ? c.toUpperCase() : c) : c)).join("")); } },
    { name: "clap", async execute(sock, from, args, msg) { const t = textOf(args, msg); if (!t) return needs(sock, from, msg, "clap <text>"); await say(sock, from, msg, t.split(/\s+/).join(" 👏 ") + " 👏"); } },
    {
        name: "repeat",
        async execute(sock, from, args, msg) {
            const n = parseInt(args[0], 10);
            const t = args.slice(1).join(" ");
            if (!n || !t) return needs(sock, from, msg, "repeat 5 hello");
            await say(sock, from, msg, clip(Array(Math.min(n, 50)).fill(t).join("\n")));
        }
    },
    {
        name: "count", aliases: ["wordcount"],
        async execute(sock, from, args, msg) {
            const t = textOf(args, msg);
            if (!t) return needs(sock, from, msg, "count <text>");
            await say(sock, from, msg, box("TEXT COUNT", [`🔤 *Characters:* ${t.length}`, `📝 *Words:* ${t.trim().split(/\s+/).length}`, `📄 *Lines:* ${t.split("\n").length}`]));
        }
    },
    {
        name: "fancy", aliases: ["styletext", "font"],
        async execute(sock, from, args, msg) {
            const t = textOf(args, msg);
            if (!t) return needs(sock, from, msg, "fancy <text>");
            await say(sock, from, msg, Object.entries(STYLES).map(([k, fn]) => `*${k}:* ${fn(t)}`).join("\n\n"));
        }
    },

    // ───────────── calculators ─────────────
    {
        name: "bmi",
        async execute(sock, from, args, msg) {
            const kg = parseFloat(args[0]), cm = parseFloat(args[1]);
            if (!kg || !cm) return needs(sock, from, msg, "bmi <kg> <cm>   e.g. bmi 70 175");
            const v = kg / Math.pow(cm / 100, 2);
            const label = v < 18.5 ? "Underweight" : v < 25 ? "Healthy" : v < 30 ? "Overweight" : "Obese";
            await say(sock, from, msg, box("BMI", [`⚖️ *${kg} kg*  📏 *${cm} cm*`, `📊 *BMI:* ${v.toFixed(1)}`, `🏷️ *Result:* ${label}`]));
        }
    },
    {
        name: "age",
        async execute(sock, from, args, msg) {
            const d = new Date(args[0]);
            if (!args[0] || isNaN(d) || d > new Date()) return needs(sock, from, msg, "age 2001-05-14   (year-month-day)");
            const now = new Date();
            let y = now.getFullYear() - d.getFullYear(), m = now.getMonth() - d.getMonth(), day = now.getDate() - d.getDate();
            if (day < 0) { m--; day += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
            if (m < 0) { y--; m += 12; }
            const next = new Date(now.getFullYear(), d.getMonth(), d.getDate()); if (next < now) next.setFullYear(now.getFullYear() + 1);
            await say(sock, from, msg, box("AGE", [`🎂 *${y} years, ${m} months, ${day} days*`, `🎉 *Next birthday in:* ${Math.ceil((next - now) / 86400000)} days`]));
        }
    }
];
