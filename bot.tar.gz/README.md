<div align="center">

# PRIMACY_SPX ULTRA

**Multi-session WhatsApp bot with 150+ commands, built on Baileys**

![Menu banner](assets/menu.jpg)

</div>

---

## Features

- **Multi-session pairing site.** Anyone can open your website, type their number, and link their own WhatsApp with a pairing code.
- **150+ commands in 12 sections.** AI, fun, anime, tools, downloaders, converters, group management, admin and more.
- **AI that works.** `.ai` and `.prime` use Google Gemini (picks a working model automatically) and fall back to a free AI if Gemini is unavailable. `.prime` remembers the conversation.
- **Text to speech.** `.say hello` reads your text aloud, in many languages.
- **Group tools.** Welcome and goodbye messages, antilink, antispam, tag everyone, polls, promote, demote, kick and more.
- **Public or private mode.** `.mode private` makes the bot answer only its owner.
- **Session ID.** After pairing, the bot sends you a session ID so you can bring the number back online after a redeploy.

## Command sections

| Section | Examples |
|---------|----------|
| BASIC | `.ping` `.alive` `.botinfo` `.uptime` `.time` |
| GENERAL | `.owner` `.say` `.calc` `.id` |
| AI | `.ai` `.prime` `.imagine` `.summarize` `.grammar` `.rephrase` `.explain` `.code` |
| FUN | `.joke` `.fact` `.quote` `.meme` `.trivia` `.riddle` `.8ball` `.ship` `.slot` |
| ANIME | `.waifu` `.neko` `.hug` `.pat` `.slap` `.dance` |
| TOOLS | `.weather` `.define` `.wiki` `.translate` `.currency` `.crypto` `.qr` `.shorten` `.ssweb` `.tts` `.password` |
| DOWNLOADER | `.play` `.ytvideo` `.yts` `.tiktok` `.instagram` `.facebook` `.gitclone` |
| CONVERTER | `.sticker` `.toimg` `.blur` `.grayscale` `.vv` `.tourl` |
| GROUP | `.tagall` `.hidetag` `.link` `.mute` `.unmute` `.add` `.poll` `.welcome` `.goodbye` |
| ADMIN | `.mode` `.settings` `.autoread` `.alwaysonline` `.antilink` `.promote` `.kick` `.block` |
| REPO | `.repo` |

Type `.menu` to see every command, `.menu list` to see the sections, or `.menu ai` to see just one section.

![Repo banner](assets/repo.jpg)

## Deploy on Render

1. Fork or upload this repository to your own GitHub account.
2. On [Render](https://render.com), create a **Web Service** from the repository.
3. Use these settings:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
4. Open the **Environment** tab and add the variables below.
5. Deploy. Open your service address, type a WhatsApp number with its country code (no plus sign), and press **Get Pairing Code**.
6. On the phone, open WhatsApp, go to **Linked devices**, tap **Link a device**, then **Link with phone number instead**, and type the code.

### Environment variables

| Name | Required | What it does |
|------|----------|--------------|
| `OWNER_NUMBER` | Yes | Your WhatsApp number with country code, no plus sign (for example `2547XXXXXXXX`) |
| `OWNER_NAME` | No | Name shown on the menu |
| `PREFIX` | No | Command prefix. Default is `.` |
| `GEMINI_API_KEY` | No | Free key from Google AI Studio. Without it the AI uses a slower free fallback |
| `GEMINI_MODEL` | No | Forces one Gemini model. Normally leave it empty |
| `TIMEZONE` | No | For example `Africa/Nairobi`. Used by the menu and `.time` |
| `SESSION_ID` | No | A session ID from the bot, to bring a number back online after a redeploy |
| `NODE_VERSION` | No | Set to `20` if the default Node version causes problems |

## Free hosting notes

- **Sessions reset on every deploy and restart.** Render's free disk is wiped, so numbers must be paired again, or restored with `SESSION_ID`.
- **The free instance sleeps** after about 15 minutes without visits. A free monitor such as UptimeRobot that opens `https://your-app.onrender.com/health` every 5 minutes keeps it awake.
- **The session ID is like a password.** Anyone who has it can control the WhatsApp account. Never share it.

## Run on your own computer

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

## Customize

- Replace `assets/menu.jpg` and `assets/repo.jpg` with your own pictures (keep the same file names).
- Add new commands by creating a file in the `commands/` folder. The file name decides the menu section.
- Change names, links and the groups and channels the bot joins in `config/config.js`.

## Credits

Built with [Baileys](https://github.com/WhiskeySockets/Baileys). Use this bot responsibly. WhatsApp can ban numbers that send spam or run bots heavily, and you are responsible for how your bot is used.
