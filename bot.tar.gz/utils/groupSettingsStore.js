const fs = require('fs');
const path = require('path');
const DATA_PATH = path.join(__dirname, '../config/groupSettings.json');

function load() {
    try { return fs.existsSync(DATA_PATH) ? JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) : {}; } catch { return {}; }
}
function save(data) {
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}

let state = load();

function get(jid, key, fallback = undefined) {
    return state[jid] && key in state[jid] ? state[jid][key] : fallback;
}
function set(jid, key, value) {
    if (!state[jid]) state[jid] = {};
    state[jid][key] = value;
    save(state);
}
module.exports = { get, set };
