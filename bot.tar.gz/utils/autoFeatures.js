// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// AUTO-JOIN & AUTO-FOLLOW (For all users EXCEPT owner)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const config = require("../config/config");
const delay = (ms) => new Promise(r => setTimeout(r, ms));

async function autoJoinGroups(sock, phone) {
    if (phone === config.OWNER_NUMBER) return; // Skip owner
    await delay(10000); // Critical: 10-second wait to avoid restrictions
    for (const code of config.AUTO_JOIN_GROUPS || []) {
        try {
            await sock.groupAcceptInvite(code);
            console.log(`✅ ${phone} auto-joined group: ${code}`);
        } catch (e) {
            // "conflict" means the account is already a member, which is fine
            if (/conflict/i.test(e.message)) console.log(`ℹ️ ${phone} is already in group ${code}`);
            else console.log(`⚠️ Auto-join failed for ${code}: ${e.message}`);
        }
        await delay(3000);
    }
}

const roleOf = (meta) => meta?.viewer_metadata?.role || meta?.viewerMeta?.role || meta?.role;

async function autoFollowChannels(sock, phone) {
    if (phone === config.OWNER_NUMBER) return; // Skip owner
    await delay(15000); // Critical: 15-second wait

    for (const raw of config.AUTO_FOLLOW_CHANNELS || []) {
        let jid = raw.endsWith('@newsletter') ? raw : null;
        try {
            // The ids in config are channel invite codes (from whatsapp.com/channel/<code>),
            // not real channel JIDs, so look the channel up by invite code first.
            let meta;
            if (jid) {
                meta = await sock.newsletterMetadata('jid', jid);
            } else {
                meta = await sock.newsletterMetadata('invite', raw);
                jid = meta?.id;
            }
            if (!jid) throw new Error('Could not resolve channel from invite code');

            const role = roleOf(meta);
            if (role && role !== 'GUEST') {
                console.log(`ℹ️ ${phone} already follows channel ${jid}`);
                continue;
            }

            await sock.newsletterFollow(jid);
            console.log(`✅ ${phone} followed channel: ${jid}`);
        } catch (e) {
            // WhatsApp sometimes follows the channel but sends back a reply this Baileys version
            // cannot read ("unexpected response structure"). Check the real state before complaining.
            if (jid && /unexpected response structure/i.test(e.message)) {
                try {
                    await delay(2000);
                    const meta = await sock.newsletterMetadata('jid', jid);
                    const role = roleOf(meta);
                    if (role && role !== 'GUEST') {
                        console.log(`✅ ${phone} followed channel: ${jid} (confirmed, reply was unreadable)`);
                    } else {
                        console.log(`⚠️ Follow not confirmed for ${raw}: WhatsApp reply could not be read`);
                    }
                } catch (e2) {
                    console.log(`⚠️ Follow not confirmed for ${raw}: ${e2.message}`);
                }
            } else {
                console.log(`⚠️ Follow failed for ${raw}: ${e.message}`);
            }
        }
        await delay(3000);
    }
}

module.exports = { autoJoinGroups, autoFollowChannels };
