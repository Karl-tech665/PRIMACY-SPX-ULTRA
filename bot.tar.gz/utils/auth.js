const config = require("../config/config");

const clean = (jid) => String(jid || "").split("@")[0].split(":")[0];

function isDev(sender) {
    return !!sender && clean(sender) === String(config.OWNER_NUMBER);
}

// The person who paired this session, or messages typed from the bot's own account
function isSessionOwner(sender, extra) {
    if (extra && extra.fromMe) return true;
    if (!sender || !extra || !extra.sessionOwner) return false;
    return clean(sender) === String(extra.sessionOwner);
}

function isOwner(sender, extra) {
    return isDev(sender) || isSessionOwner(sender, extra);
}

// WhatsApp groups can list people by phone number or by a hidden "lid", so compare every id we are given
function sameUser(participant, target) {
    return [participant.id, participant.jid, participant.lid, participant.phoneNumber]
        .filter(Boolean).some(x => clean(x) === target);
}

async function isAdmin(sock, from, sender) {
    try {
        const meta = await sock.groupMetadata(from);
        const target = clean(sender);
        const p = meta.participants.find(x => sameUser(x, target));
        return p?.admin === "admin" || p?.admin === "superadmin";
    } catch (e) { return false; }
}

async function isBotAdmin(sock, from) {
    try {
        const meta = await sock.groupMetadata(from);
        const ids = [sock.user?.id, sock.user?.lid].filter(Boolean).map(clean);
        const p = meta.participants.find(x => ids.some(id => sameUser(x, id)));
        return p?.admin === "admin" || p?.admin === "superadmin";
    } catch (e) { return false; }
}

module.exports = { isDev, isSessionOwner, isOwner, isAdmin, isBotAdmin };
