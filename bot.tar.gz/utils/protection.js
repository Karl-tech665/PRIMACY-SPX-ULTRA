const { isAdmin } = require('./auth');
const groupSettings = require('./groupSettingsStore');

const spamTracker = new Map();

async function enforceProtection(sock, from, sender, msg, text) {
    try {
        const senderIsAdmin = await isAdmin(sock, from, sender);
        if (senderIsAdmin || msg.key.fromMe) return false;

        const antilinkOn = groupSettings.get(from, 'antilink', true);
        const antispamOn = groupSettings.get(from, 'antispam', true);

        if (antilinkOn) {
            const linkRegex = /(https?:\/\/[^\s]+|wa\.me\/[^\s]+|chat\.whatsapp\.com\/[^\s]+)/gi;
            if (linkRegex.test(text)) {
                await sock.sendMessage(from, { delete: msg.key });
                await sock.sendMessage(from, { text: `⚠️ *ANTILINK DETECTED!*\n@${sender.split('@')[0]}, links are not allowed here.`, mentions: [sender] });
                return true; 
            }
        }

        if (antispamOn) {
            const now = Date.now();
            const userKey = `${from}_${sender}`;
            
            if (!spamTracker.has(userKey)) {
                spamTracker.set(userKey, { count: 1, startTime: now });
            } else {
                const data = spamTracker.get(userKey);
                if (now - data.startTime < 3000) {
                    data.count++;
                    if (data.count >= 4) { 
                        await sock.sendMessage(from, { delete: msg.key });
                        await sock.sendMessage(from, { text: `🛑 *SPAM DETECTED!*\n@${sender.split('@')[0]}, please slow down.`, mentions: [sender] });
                        spamTracker.delete(userKey); 
                        return true;
                    }
                } else {
                    spamTracker.set(userKey, { count: 1, startTime: now });
                }
            }
        }
        if (spamTracker.size > 5000) spamTracker.clear();
        return false;
    } catch (e) { return false; }
}
module.exports = { enforceProtection };
