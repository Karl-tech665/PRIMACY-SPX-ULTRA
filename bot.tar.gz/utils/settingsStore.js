const fs = require('fs');
const path = require('path');
const DATA_PATH = path.join(__dirname, '../config/settings.json');

function load() {
    try { return fs.existsSync(DATA_PATH) ? JSON.parse(fs.readFileSync(DATA_PATH, 'utf8')) : {}; } catch { return {}; }
}
function save(data) {
    fs.mkdirSync(path.dirname(DATA_PATH), { recursive: true });
    fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}

let state = load();

function get(key, fallback = undefined) { return key in state ? state[key] : fallback; }
function set(key, value) { state[key] = value; save(state); }

module.exports = { get, set };
