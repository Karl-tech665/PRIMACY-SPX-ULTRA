const fs = require("fs");
const path = require("path");
const settingsStore = require("./settingsStore");
const { isOwner } = require("./auth");

// Menu heading for each command file (a file that is not listed uses its own name)
const CATEGORY_LABELS = {
    core: "BASIC",
    general: "GENERAL",
    ai: "AI",
    fun: "FUN",
    anime: "ANIME",
    tools: "TOOLS",
    media: "DOWNLOADER",
    converter: "CONVERTER",
    group: "GROUP",
    admin: "ADMIN",
    repo: "REPO",
    menu: "MENU"
};

// Wraps a command so ".mode private" works: in private mode only the owner gets a reply
function withModeCheck(cmd) {
    if (cmd.__modeChecked) return;
    cmd.__modeChecked = true;
    const original = cmd.execute;
    cmd.execute = function (sock, from, args, msg, extra = {}) {
        const mode = settingsStore.get(`${extra.sessionOwner}_mode`, "public");
        if (mode === "private" && !isOwner(extra.sender, extra)) return; // ignored silently
        return original.call(this, sock, from, args, msg, extra);
    };
}

function loadCommands(commandsPath) {
    const commands = new Map();
    if (!fs.existsSync(commandsPath)) return commands;

    const files = fs.readdirSync(commandsPath).filter(f => f.endsWith(".js")).sort();
    for (const file of files) {
        try {
            const exported = require(path.join(commandsPath, file));
            const list = Array.isArray(exported) ? exported : [exported];
            const base = path.basename(file, ".js");
            const category = CATEGORY_LABELS[base] || base.toUpperCase();

            for (const cmd of list) {
                if (!cmd || !cmd.name || !cmd.execute) continue;
                if (!cmd.category) cmd.category = category;
                withModeCheck(cmd);
                if (commands.has(cmd.name)) console.log(`⚠️ Duplicate command "${cmd.name}" in ${file} replaces an earlier one`);
                commands.set(cmd.name, cmd);
                for (const alias of cmd.aliases || []) {
                    if (!commands.has(alias)) commands.set(alias, cmd);
                }
            }
        } catch (e) {
            console.error(`❌ Failed to load command file "${file}": ${e.message}`);
        }
    }
    console.log(`✅ Loaded ${new Set(commands.values()).size} commands (${commands.size} names including aliases).`);
    return commands;
}

module.exports = { loadCommands };
