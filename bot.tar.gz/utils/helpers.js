const fs = require("fs");

function formatUptime() {
    const u = process.uptime();
    const d = Math.floor(u / 86400);
    const h = Math.floor((u % 86400) / 3600);
    const m = Math.floor((u % 3600) / 60);
    const s = Math.floor(u % 60);
    if (d > 0) return `${d}d ${h}h ${m}m`;
    if (h > 0) return `${h}h ${m}m ${s}s`;
    return `${m}m ${s}s`;
}

function getRAMUsage() {
    let totalMB = 512; // Render free tier limit
    try {
        const raw = fs.readFileSync("/sys/fs/cgroup/memory.max", "utf8").trim();
        if (raw !== "max") totalMB = Number(raw) / 1048576;
    } catch (e) {}

    const usedMB = process.memoryUsage().rss / 1048576;
    const percent = Math.round((usedMB / totalMB) * 100);
    const filled = Math.min(10, Math.round(percent / 10));
    const bar = "█".repeat(filled) + "░".repeat(10 - filled);

    return { used: usedMB.toFixed(1), total: totalMB.toFixed(0), percent, bar };
}

async function getSpeed() {
    const start = process.hrtime.bigint();
    await new Promise(r => setImmediate(r));
    return `${(Number(process.hrtime.bigint() - start) / 1e6).toFixed(0)} ms`;
}

async function animateMessage(sock, from, frames, delayMs = 400) {
    if (!Array.isArray(frames) || frames.length === 0) return null;
    let sent;
    try { sent = await sock.sendMessage(from, { text: frames[0] }); } catch (e) { return null; }
    for (let i = 1; i < frames.length; i++) {
        await new Promise(r => setTimeout(r, delayMs));
        try { await sock.sendMessage(from, { text: frames[i], edit: sent.key }); } catch (e) { break; }
    }
    return sent;
}

// ── small shared helpers used by many commands ──
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const clip = (s, n = 3500) => (String(s).length > n ? String(s).slice(0, n - 1) + "…" : String(s));
const jidNum = (jid) => String(jid || "").split("@")[0].split(":")[0];

// A neat box used by lots of commands
function box(title, lines) {
    const body = (Array.isArray(lines) ? lines : [lines]).map(l => `┃ ${l}`).join("\n");
    return `╭━━━〔 *${title}* 〕━━━╮\n${body}\n╰━━━━━━━━━━━━━━━━━━━━╯`;
}

// Returns a Buffer for a local file (preferred) or { url } for a web address, or null if missing
function readImage(src) {
    if (!src) return null;
    if (/^https?:\/\//i.test(src)) return { url: src };
    try { return fs.readFileSync(src); } catch (e) { return null; }
}

// Text from the command arguments, or from the message being replied to
function textFrom(args, msg) {
    if (args.length) return args.join(" ");
    const q = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    return q?.conversation || q?.extendedTextMessage?.text || q?.imageMessage?.caption || q?.videoMessage?.caption || "";
}

module.exports = { formatUptime, getRAMUsage, getSpeed, animateMessage, sleep, pick, clip, jidNum, box, readImage, textFrom };
