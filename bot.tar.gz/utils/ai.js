const axios = require("axios");

// ─── Gemini (needs GEMINI_API_KEY) ───
// Google retires old model names often (gemini-1.5-flash now returns 404), so instead of hard-coding
// one we ask Google which models this key can use and pick the newest "flash" model.
// To force a model yourself, set GEMINI_MODEL on Render.
let cachedModel = null;
let cachedAt = 0;

async function pickGeminiModel(key, force = false) {
    if (process.env.GEMINI_MODEL) return process.env.GEMINI_MODEL;
    if (!force && cachedModel && Date.now() - cachedAt < 6 * 3600 * 1000) return cachedModel;

    const r = await axios.get("https://generativelanguage.googleapis.com/v1beta/models", {
        headers: { "x-goog-api-key": key }, params: { pageSize: 200 }, timeout: 20000
    });
    const names = (r.data.models || [])
        .filter(m => (m.supportedGenerationMethods || []).includes("generateContent"))
        .map(m => m.name.replace(/^models\//, ""))
        .filter(n => /^gemini-/.test(n) && !/(image|live|audio|tts|embed|vision|robotics|computer|thinking|exp|deep|learnlm|customtools)/i.test(n));

    const score = (n) => {
        const v = parseFloat((n.match(/^gemini-(\d+(?:\.\d+)?)/) || [0, 0])[1]);
        let s = v * 100;
        if (/flash/.test(n)) s += 30; else if (/pro/.test(n)) s += 10;
        if (/lite/.test(n)) s -= 8;
        if (/preview/.test(n)) s -= 15;
        return s;
    };
    names.sort((a, b) => score(b) - score(a));
    if (!names.length) throw new Error("No Gemini model available for this API key");
    cachedModel = names[0];
    cachedAt = Date.now();
    console.log(`🤖 Gemini model selected: ${cachedModel}`);
    return cachedModel;
}

async function gemini(prompt, { system, history = [] } = {}) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) throw new Error("NO_KEY");

    for (let attempt = 0; attempt < 2; attempt++) {
        const model = await pickGeminiModel(key, attempt > 0);
        try {
            const body = {
                contents: [
                    ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
                    { role: "user", parts: [{ text: prompt }] }
                ],
                generationConfig: { temperature: 0.8, maxOutputTokens: 1200 }
            };
            if (system) body.systemInstruction = { parts: [{ text: system }] };
            const r = await axios.post(
                `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
                body, { headers: { "x-goog-api-key": key }, timeout: 45000 }
            );
            const text = (r.data?.candidates?.[0]?.content?.parts || []).map(p => p.text).filter(Boolean).join("").trim();
            if (!text) throw new Error("Gemini returned an empty answer");
            return { text, source: model };
        } catch (e) {
            const status = e.response?.status;
            if (attempt === 0 && (status === 404 || status === 400) && !process.env.GEMINI_MODEL) { cachedModel = null; continue; }
            throw e;
        }
    }
}

// ─── Free fallback (no key needed, but slow and rate limited) ───
async function pollinations(prompt, system) {
    const short = String(prompt).slice(0, 1500);
    const r = await axios.get("https://text.pollinations.ai/" + encodeURIComponent(short), {
        params: { model: "openai", ...(system ? { system: String(system).slice(0, 800) } : {}) },
        timeout: 50000, responseType: "text", transformResponse: x => x
    });
    const text = String(r.data || "").trim();
    if (!text) throw new Error("Empty answer");
    return { text, source: "pollinations" };
}

// Tries Gemini first, then the free fallback. Throws a friendly error if both fail.
async function ask(prompt, opts = {}) {
    let geminiError = null;
    if (process.env.GEMINI_API_KEY) {
        try { return await gemini(prompt, opts); }
        catch (e) { geminiError = e; console.log("⚠️ Gemini failed:", e.response?.status || "", e.response?.data?.error?.message || e.message); }
    }
    try { return await pollinations(prompt, opts.system); }
    catch (e) {
        console.log("⚠️ Free AI fallback failed:", e.message);
        const why = geminiError ? (geminiError.response?.data?.error?.message || geminiError.message) : "GEMINI_API_KEY is not set";
        throw new Error(`AI is unavailable right now (${String(why).slice(0, 120)})`);
    }
}

// ─── Image generation (free, no key) ───
async function imageUrl(prompt) {
    const seed = Math.floor(Math.random() * 1e6);
    return `https://image.pollinations.ai/prompt/${encodeURIComponent(String(prompt).slice(0, 400))}?width=1024&height=1024&nologo=true&seed=${seed}`;
}

module.exports = { ask, gemini, pollinations, imageUrl };
