const axios = require("axios");
const { getBuffer } = require("./net");

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ─── Gemini (needs GEMINI_API_KEY) ───
// Google retires old model names often, so instead of hard-coding one we ask Google which models this key
// can use. Stable models are tried first (preview models are the ones that are often "overloaded"), and if
// one is busy the next one is tried. To force a model yourself, set GEMINI_MODEL on Render.
let cachedModels = null;
let cachedAt = 0;

async function listGeminiModels(key, force = false) {
    if (!force && cachedModels && Date.now() - cachedAt < 6 * 3600 * 1000) return cachedModels;

    const r = await axios.get("https://generativelanguage.googleapis.com/v1beta/models", {
        headers: { "x-goog-api-key": key }, params: { pageSize: 200 }, timeout: 20000
    });
    const names = (r.data.models || [])
        .filter(m => (m.supportedGenerationMethods || []).includes("generateContent"))
        .map(m => m.name.replace(/^models\//, ""))
        .filter(n => /^gemini-/.test(n) && !/(image|live|audio|tts|embed|vision|robotics|computer|thinking|exp|deep|learnlm|customtools)/i.test(n));

    const score = (n) => {
        const v = parseFloat((n.match(/^gemini-(\d+(?:\.\d+)?)/) || [0, 0])[1]);
        let s = v * 100;
        if (/flash/.test(n)) s += 30; else if (/pro/.test(n)) s += 10;
        if (/lite/.test(n)) s -= 8;
        if (/preview/.test(n)) s -= 150; // previews are tried only after the stable models
        return s;
    };
    names.sort((a, b) => score(b) - score(a));
    if (!names.length) throw new Error("No Gemini model available for this API key");
    cachedModels = names;
    cachedAt = Date.now();
    console.log(`🤖 Gemini models ranked: ${names.slice(0, 4).join(", ")}`);
    return names;
}

async function gemini(prompt, { system, history = [] } = {}) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) throw new Error("NO_KEY");

    const body = {
        contents: [
            ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
            { role: "user", parts: [{ text: prompt }] }
        ],
        generationConfig: { temperature: 0.8, maxOutputTokens: 1200 }
    };
    if (system) body.systemInstruction = { parts: [{ text: system }] };

    let models;
    try { models = process.env.GEMINI_MODEL ? [process.env.GEMINI_MODEL] : (await listGeminiModels(key)).slice(0, 4); }
    catch (e) { throw e; }

    let lastError;
    for (const model of models) {
        for (let attempt = 0; attempt < 2; attempt++) {
            try {
                const r = await axios.post(
                    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
                    body, { headers: { "x-goog-api-key": key }, timeout: 35000 }
                );
                const text = (r.data?.candidates?.[0]?.content?.parts || []).map(p => p.text).filter(Boolean).join("").trim();
                if (!text) throw new Error("Gemini returned an empty answer");
                return { text, source: model };
            } catch (e) {
                lastError = e;
                const status = e.response?.status;
                if ((status === 503 || status === 429 || status === 500) && attempt === 0) { await sleep(1500); continue; } // busy: one quick retry
                break; // otherwise move on to the next model
            }
        }
    }
    cachedModels = null; // refresh the list next time
    throw lastError;
}

// ─── Free fallback (no key needed, but slow and rate limited) ───
async function pollinations(prompt, system) {
    const short = String(prompt).slice(0, 1500);
    const r = await axios.get("https://text.pollinations.ai/" + encodeURIComponent(short), {
        params: { model: "openai", ...(system ? { system: String(system).slice(0, 800) } : {}) },
        timeout: 50000, responseType: "text", transformResponse: x => x
    });
    const text = String(r.data || "").trim();
    if (!text) throw new Error("Empty answer");
    return { text, source: "pollinations" };
}

// Tries Gemini first, then the free fallback. Throws a friendly error if both fail.
async function ask(prompt, opts = {}) {
    let geminiError = null;
    if (process.env.GEMINI_API_KEY) {
        try { return await gemini(prompt, opts); }
        catch (e) { geminiError = e; console.log("⚠️ Gemini failed:", e.response?.status || "", e.response?.data?.error?.message || e.message); }
    }
    try { return await pollinations(prompt, opts.system); }
    catch (e) {
        console.log("⚠️ Free AI fallback failed:", e.message);
        const why = geminiError ? (geminiError.response?.data?.error?.message || geminiError.message) : "GEMINI_API_KEY is not set";
        throw new Error(`The AI is very busy right now, please try again in a minute. (${String(why).slice(0, 100)})`);
    }
}

// ─── Image generation (free, no key) ───
// The free service is often busy (error 503), so a few attempts are made with different image models.
async function generateImage(prompt) {
    let last;
    for (const model of ["flux", "turbo", ""]) {
        try {
            const seed = Math.floor(Math.random() * 1e6);
            const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(String(prompt).slice(0, 400))}?width=1024&height=1024&nologo=true&seed=${seed}${model ? `&model=${model}` : ""}`;
            const buf = await getBuffer(url, { timeout: 70000 });
            if (buf.length > 2000) return buf;
            throw new Error("empty image");
        } catch (e) { last = e; await sleep(2500); }
    }
    throw last;
}

module.exports = { ask, gemini, pollinations, generateImage };
