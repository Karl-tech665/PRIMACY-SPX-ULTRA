const { downloadMediaMessage } = require("@whiskeysockets/baileys");

const quietLogger = { level: "silent", child() { return this; }, trace() {}, debug() {}, info() {}, warn() {}, error() {} };

function unwrap(m) {
    if (!m) return null;
    return m.ephemeralMessage?.message || m.viewOnceMessage?.message || m.viewOnceMessageV2?.message ||
        m.viewOnceMessageV2Extension?.message || m.documentWithCaptionMessage?.message || m;
}

function pickMedia(m) {
    if (!m) return null;
    for (const k of ["imageMessage", "videoMessage", "stickerMessage", "audioMessage", "documentMessage"]) {
        if (m[k]) return { kind: k.replace("Message", ""), node: m[k] };
    }
    return null;
}

// Finds media in the message itself, or in the message it replies to
function getMediaTarget(msg) {
    const m = unwrap(msg.message);
    const direct = pickMedia(m);
    if (direct) return { ...direct, msg: { key: msg.key, message: m } };

    const ctx = m?.extendedTextMessage?.contextInfo || m?.imageMessage?.contextInfo || m?.videoMessage?.contextInfo;
    const quoted = unwrap(ctx?.quotedMessage);
    const q = pickMedia(quoted);
    if (q) {
        return {
            ...q,
            msg: { key: { remoteJid: msg.key.remoteJid, id: ctx.stanzaId, participant: ctx.participant, fromMe: false }, message: quoted }
        };
    }
    return null;
}

async function download(sock, target) {
    return downloadMediaMessage(target.msg, "buffer", {}, { logger: quietLogger, reuploadRequest: sock.updateMediaMessage });
}

module.exports = { getMediaTarget, download, unwrap };
