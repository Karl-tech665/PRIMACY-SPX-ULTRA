const { BufferJSON } = require("@whiskeysockets/baileys");
const config = require("../config/config");
const { formatUptime, getRAMUsage, readImage, box } = require("./helpers");

// Sent once, right after a number is paired
async function sendWelcome(sock, phone, commands) {
    const jid = phone + "@s.whatsapp.net";
    const total = new Set(commands.values()).size;
    const ram = getRAMUsage();
    const caption = box(config.BOT_NAME, [
        "✅ *CONNECTED & ACTIVE*",
        `📱 *Number:* ${phone}`,
        `🔑 *Prefix:* ${config.PREFIX}`,
        `📦 *Commands:* ${total}`,
        `🧠 *RAM:* ${ram.used}MB / ${ram.total}MB`,
        `⏱️ *Uptime:* ${formatUptime()}`
    ]) + `\n\n👉 Type *${config.PREFIX}menu* to see everything I can do.\n\n✦ 𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 ${config.FOOTER_BRAND} ✦`;

    const img = readImage(config.MENU_IMAGE);
    if (img) {
        try { await sock.sendMessage(jid, { image: img, caption }); return; } catch (e) { console.log("⚠️ Welcome image failed:", e.message); }
    }
    await sock.sendMessage(jid, { text: caption });
}

// Sent as its own messages, a few seconds after the welcome card:
// first a short warning, then the session ID alone so it is easy to copy.
async function sendSessionId(sock, phone, creds) {
    const jid = phone + "@s.whatsapp.net";
    const sessionId = "PRIMACY-SPX:~" + Buffer.from(JSON.stringify(creds, BufferJSON.replacer)).toString("base64");

    await sock.sendMessage(jid, { text:
        "🔐 *YOUR SESSION ID*\n\n" +
        "⚠️ Keep it private. Anyone who has it can control your WhatsApp account, so never post it in a group or send it to anyone.\n\n" +
        "📌 *How to use it:* on Render open *Environment*, add a variable named *SESSION_ID* and paste the next message into it (the whole text, starting with PRIMACY-SPX:~). " +
        "After the next deploy your number comes back online without pairing again. Never use the same ID on two servers at once."
    });
    await new Promise(r => setTimeout(r, 1500));
    await sock.sendMessage(jid, { text: sessionId });
}

module.exports = { sendWelcome, sendSessionId };
