const { BufferJSON } = require("@whiskeysockets/baileys");
const config = require("../config/config");
const { formatUptime, getRAMUsage, readImage, box } = require("./helpers");

// Sent once, right after a number is paired
async function sendWelcome(sock, phone, commands) {
    const jid = phone + "@s.whatsapp.net";
    const total = new Set(commands.values()).size;
    const ram = getRAMUsage();
    const caption = box(config.BOT_NAME, [
        "✅ *CONNECTED & ACTIVE*",
        `📱 *Number:* ${phone}`,
        `🔑 *Prefix:* ${config.PREFIX}`,
        `📦 *Commands:* ${total}`,
        `🧠 *RAM:* ${ram.used}MB / ${ram.total}MB`,
        `⏱️ *Uptime:* ${formatUptime()}`
    ]) + `\n\n👉 Type *${config.PREFIX}menu* to see everything I can do.\n\n✦ 𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 ${config.FOOTER_BRAND} ✦`;

    const img = readImage(config.MENU_IMAGE);
    if (img) {
        try { await sock.sendMessage(jid, { image: img, caption }); return; } catch (e) { console.log("⚠️ Welcome image failed:", e.message); }
    }
    await sock.sendMessage(jid, { text: caption });
}

// Sent on its own, a few seconds after the welcome card
async function sendSessionId(sock, phone, creds) {
    const jid = phone + "@s.whatsapp.net";
    const sessionId = "PRIMACY-SPX:~" + Buffer.from(JSON.stringify(creds, BufferJSON.replacer)).toString("base64");
    await sock.sendMessage(jid, { text: sessionId });
}

module.exports = { sendWelcome, sendSessionId };
