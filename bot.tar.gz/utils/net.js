const axios = require("axios");

const http = axios.create({
    timeout: 25000,
    headers: { "User-Agent": "Mozilla/5.0 (compatible; PRIMACY_SPX/2.1)" }
});

async function getJson(url, opts = {}) {
    const r = await http.get(url, opts);
    return r.data;
}

async function getBuffer(url, opts = {}) {
    const r = await http.get(url, { responseType: "arraybuffer", timeout: 60000, ...opts });
    return Buffer.from(r.data);
}

async function getText(url, opts = {}) {
    const r = await http.get(url, { responseType: "text", transformResponse: x => x, ...opts });
    return String(r.data);
}

module.exports = { http, getJson, getBuffer, getText };
